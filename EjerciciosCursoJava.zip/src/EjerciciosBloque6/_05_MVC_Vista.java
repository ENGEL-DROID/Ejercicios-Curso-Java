package EjerciciosBloque6;

import java.awt.BorderLayout;
import java.sql.SQLException;

import javax.swing.*;

public class _05_MVC_Vista extends JFrame {

	public JPanel miPanel;
	public JComboBox comboSeccion, comboPais;
	public JTextArea areaTxt;
	private JScrollPane vistaScroll;
	public JButton btnConsulta;
	
	public _05_MVC_Vista() {
		// Marco
		setSize(400, 500);
		setTitle("Aplicaci�n MVC");
		setLocationRelativeTo(null);
		// Men�s Secci�n y Pa�s
		add(miPanel = new JPanel(), BorderLayout.NORTH);
		miPanel.add(comboSeccion = new JComboBox());
		miPanel.add(comboPais = new JComboBox());
		comboSeccion.addItem("Todo");
		comboPais.addItem("Todo");
		// �rea de texto
		add(areaTxt = new JTextArea());
		areaTxt.setEditable(false);
		add(vistaScroll = new JScrollPane(areaTxt), BorderLayout.CENTER);
		// Bot�n Consulta
		add(btnConsulta = new JButton("Consulta"), BorderLayout.SOUTH);
		_05_MVC_Controlador miOyente = new _05_MVC_Controlador(comboSeccion, comboPais, areaTxt);
		btnConsulta.addActionListener(miOyente);
		// Agregar Data a Men�s
		_05_MVC_Modelo agregarMenus = new _05_MVC_Modelo();
		agregarMenus.cargarSeccion(comboSeccion);
		agregarMenus.cargarPais(comboPais);
		try {
			agregarMenus.getMiConexion().close();
		} catch (SQLException e) {
			System.out.println("Error al Cerrar Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
