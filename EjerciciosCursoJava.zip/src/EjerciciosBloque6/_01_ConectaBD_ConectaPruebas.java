package EjerciciosBloque6;

import java.sql.*;

public class _01_ConectaBD_ConectaPruebas {

	public static void main(String[] args) {

		try {
			Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
		
			Statement stConexion = miConexion.createStatement();
			
			ResultSet rs = stConexion.executeQuery("SELECT * FROM PRODUCTOS");
			
			while (rs.next()) {
				System.out.println(rs.getString("C�DIGOART�CULO") + " | " + rs.getString("PA�SDEORIGEN") + " | " + rs.getString("SECCI�N") + " | " + rs.getString("PRECIO") );
			}
			
			// se cierra el flujo
			miConexion.close();
			
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
