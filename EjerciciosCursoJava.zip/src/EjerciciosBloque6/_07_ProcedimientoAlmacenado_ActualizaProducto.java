package EjerciciosBloque6;

import java.sql.*;
import javax.swing.JOptionPane;

public class _07_ProcedimientoAlmacenado_ActualizaProducto {

	public static void main(String[] args) {
		
		String NArticulo = JOptionPane.showInputDialog("Ingrese Nombre de Art�culo a actualizar");
		int NPrecio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el Precio a actualizar"));

		try {
			Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			
			CallableStatement miCallSt = miConexion.prepareCall("{call PRODUCTOS_PRECIOS(?,?)}");
			
			miCallSt.setInt(1, NPrecio);
			miCallSt.setString(2, NArticulo);
			
			miCallSt.execute();
			
			JOptionPane.showMessageDialog(null, "Producto Actualizado!");
			
			miConexion.close();
			
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
