package EjerciciosBloque6;

import java.sql.*;
import javax.swing.JOptionPane;

public class _09_ProcedimientoAlmacenado_Transacci�nProductos {

	public static void main(String[] args) {
		
		Connection miConexion = null;
		
		String sqlEliminarPais = "DELETE FROM PRODUCTOS WHERE PA�SDEORIGEN = 'COLOMBIA'";
		String sqlEliminarPrecio = "DELETE FROM PRODUCTOS WHERE PRECIO > 200";
		String sqlActualizarPrecio = "UPDATE PRODUCTOS SET PRECIO = PRECIO * 2.50";

		try {
			miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			miConexion.setAutoCommit(false);
			Statement miST = miConexion.createStatement();
			
			boolean eliminarPais = confirmarEliminarPais();
			boolean eliminarPrecio = confirmarEliminarPrecio();
			boolean actualizarPrecio = confirmarActualizarPrecio();
			
			if (eliminarPais && eliminarPrecio && actualizarPrecio) {
				miST.executeUpdate(sqlEliminarPais);
				miST.executeUpdate(sqlEliminarPrecio);
				miST.executeUpdate(sqlActualizarPrecio);
				miConexion.commit();
				System.out.println("Solicitud Ejecutada Exitosamente!");
			} else {
				JOptionPane.showMessageDialog(null, "Deben ser los tres Ok.\nSolicitud No Ejecutada!");
				System.out.println("Solicitud No Ejecutada!");
			} 
			
			miConexion.close();
			
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
			try {
				miConexion.rollback();
			} catch (SQLException e1) {
				System.out.println("Error en RollBack: " + e1.getMessage());
				e1.printStackTrace();
			}
		}
	}
	// M�TODO CONFIRMAR ELIMINAR PA�S
	private static boolean confirmarEliminarPais() {
		int respuesta = JOptionPane.showConfirmDialog(null, "Deseas Eliminar el Pa�s?");
		if (respuesta == 0) {
			return true;
		} else {
			return false;
		} 
	}
	// M�TODO CONFIRMAR ELIMINAR PRECIO
	private static boolean confirmarEliminarPrecio() {
		int respuesta = JOptionPane.showConfirmDialog(null, "Deseas Eliminar el Precio?");
		if (respuesta == 0) {
			return true;
		} else {
			return false;
		} 
	}
	// M�TODO CONFIRMAR ACTUALIZAR PRECIO
	private static boolean confirmarActualizarPrecio() {
		int respuesta = JOptionPane.showConfirmDialog(null, "Deseas Actualizar el Precio?");
		if (respuesta == 0) {
			return true;
		} else {
			return false;
		} 
	}
}
