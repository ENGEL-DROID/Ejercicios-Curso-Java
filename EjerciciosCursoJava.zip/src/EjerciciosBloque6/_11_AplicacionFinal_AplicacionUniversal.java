package EjerciciosBloque6;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

public class _11_AplicacionFinal_AplicacionUniversal {
	
	private static MarcoAppUni miMarco;
	private static String rutaFile = getRutaFile();

	public static void main(String[] args) {
		
		miMarco = new MarcoAppUni(getTablas(), getConexionUrl());
		
		System.out.println("Ruta File: " + rutaFile);
		System.out.println("Ruta Conexi�n: " + getConexionUrl()[0] + ", " + getConexionUrl()[1] + ", " + getConexionUrl()[2]);
	}
	
	public static String getRutaFile() {
		String rutaURL;
		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de Texto", "txt");
		chooser.setFileFilter(filter);
		int returnVal = chooser.showOpenDialog(miMarco);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			System.out.println("You chose to open this file: " + chooser.getSelectedFile().getName());
		}
		rutaURL = chooser.getSelectedFile().getPath();
		return rutaURL;
	}
	
	public static String[] getConexionUrl() {
		String[] miData = new String[3];
		try {
			FileReader miArchivo = new FileReader(rutaFile);
			BufferedReader miBuffer = new BufferedReader(miArchivo);
			for (int i = 0; i < 3; i++) {
				miData[i] = miBuffer.readLine();
			}
			miArchivo.close();
		} catch (IOException e) {
			System.out.println("Error en FileReader: " + e.getMessage());
			e.printStackTrace();
		}
		return miData;
	}
	
	public static ArrayList<String> getTablas() {
		ArrayList<String> misTablas = new ArrayList<String>();
		try {
			Connection miConexion = DriverManager.getConnection(getConexionUrl()[0], getConexionUrl()[1], getConexionUrl()[2]);
			ResultSet miData = miConexion.getMetaData().getTables(null, null, null, null);
			while (miData.next()) {
				misTablas.add(miData.getString("TABLE_NAME"));
			}
			miConexion.close();
		} catch (SQLException e) {
			System.out.println("Error en Conexi�n: " + e.getMessage());
			e.printStackTrace();
		}
		for (int i = 0; i < misTablas.size(); i++) {
			System.out.println("Tabla de la BBDD: " + misTablas.get(i));
		}
		return misTablas;
	}
}

class MarcoAppUni extends JFrame {
	public MarcoAppUni(ArrayList<String> tablas, String[] miConexion) {
		setSize(400, 500);
		setLocationRelativeTo(null);
		add(new LaminaAppUni(tablas, miConexion));
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class LaminaAppUni extends JPanel {
	private JComboBox comboTablas;
	private JTextArea textArea;
	private JScrollPane vistaScroll;
	String[] miConexion;
	String url, user, key;
	
	public LaminaAppUni(ArrayList<String> tablas, String[] miConexion) {
		this.miConexion = miConexion;
		String url = miConexion[0];
		String user = miConexion[1];
		String key = miConexion[2];
		setLayout(new BorderLayout());
		add(comboTablas = new JComboBox(), BorderLayout.NORTH);
		for (int i = 0; i < tablas.size(); i++) {
			comboTablas.addItem(tablas.get(i));
		}
		add(textArea = new JTextArea(), BorderLayout.CENTER);
		add(vistaScroll = new JScrollPane(textArea));
		textArea.setEditable(false);
		comboTablas.addActionListener(new OyenteTablas());
		System.out.println("Mi Conecci�n en L�mina: " + miConexion[0] + ", " + miConexion[1] + ", " + miConexion[2]);
		System.out.println("Mi Conecci�n Instanciada en L�mina: " + url + ", " + user + ", " + key);
	}
	
	private class OyenteTablas implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				textArea.setText("");
				Connection miConexionOyente = DriverManager.getConnection(miConexion[0], miConexion[1], miConexion[2]);
				String sql = "SELECT * FROM " + comboTablas.getSelectedItem();
				Statement miST = miConexionOyente.createStatement();
				ResultSet miRS = miST.executeQuery(sql);
				while (miRS.next()) {
					textArea.append(miRS.getString(1) + " - " + miRS.getString(2) + " - " + miRS.getString(3) + " - " + miRS.getString(4) + "\n");
				}
				miConexionOyente.close();
			} catch (SQLException e1) {
				System.out.println("Error de Conecci�n en Oyente ComboBox: " + e1.getMessage());
				e1.printStackTrace();
			}
		}
	}
}
