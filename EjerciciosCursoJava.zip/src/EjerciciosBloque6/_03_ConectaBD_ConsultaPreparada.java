package EjerciciosBloque6;

import java.sql.*;

public class _03_ConectaBD_ConsultaPreparada {

	public static void main(String[] args) {

		try {
			Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			String consulta = "SELECT NOMBREART�CULO, SECCI�N, PA�SDEORIGEN FROM PRODUCTOS WHERE SECCI�N = ? AND PA�SDEORIGEN = ?";
			PreparedStatement miSt = miConexion.prepareStatement(consulta);
			miSt.setString(1, "CER�MICA");
			miSt.setString(2, "CHINA");
			ResultSet miRs = miSt.executeQuery();
			System.out.println("\nPrimer Consulta:\n");
			while (miRs.next()) {
				System.out.println(miRs.getString(1) +  " | " + miRs.getString(2) +  " | " + miRs.getString(3));
			}
			System.out.println("\nSegunda Consulta:\n");
			miSt.setString(1, "CONFECCI�N");
			miSt.setString(2, "ESPA�A");
			ResultSet miRs2 = miSt.executeQuery();
			while (miRs2.next()) {
				System.out.println(miRs2.getString(1) +  " | " + miRs2.getString(2) +  " | " + miRs2.getString(3));
			}
			// cerrar el flujo
			miConexion.close();
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
