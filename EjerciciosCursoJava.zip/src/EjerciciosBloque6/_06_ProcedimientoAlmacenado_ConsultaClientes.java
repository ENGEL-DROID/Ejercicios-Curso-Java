package EjerciciosBloque6;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class _06_ProcedimientoAlmacenado_ConsultaClientes {

	public static void main(String[] args) {

		try {
			Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
		
			String callSql = "{call CLIENTES_MADRID}";
			
			CallableStatement miCallSt = miConexion.prepareCall(callSql);
			
			ResultSet miRs = miCallSt.executeQuery();
			
			while (miRs.next()) {
				System.out.println(miRs.getString(1) + " - " + miRs.getString(2) + " - " + miRs.getString(3));
			}
		
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
