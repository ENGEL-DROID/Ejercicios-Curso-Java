package EjerciciosBloque6;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;

public class _04_ConectaBD_AplicacionConsulta {

	public static void main(String[] args) {

		MarcoApp miMarco = new MarcoApp();
	}
}

class MarcoApp extends JFrame {
	public MarcoApp() {
		setTitle("Consulta BBDD Pipe");
		setSize(400, 500);
		setLocationRelativeTo(null);
		add(new VentanaApp());
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class VentanaApp extends JPanel {
	private JPanel comboMenus;
	private JComboBox comboSeccion, comboPais;
	private JTextArea textArea;
	private JScrollPane vistaScroll;
	private JButton btnConsulta;
	private ConectaBBDD agregaMenus;
	
	public VentanaApp() {
		setLayout(new BorderLayout());
		// Combo Men�s
		add(comboMenus = new JPanel(), BorderLayout.NORTH);
		comboMenus.add(comboSeccion = new JComboBox());
		comboMenus.add(comboPais = new JComboBox());
		comboSeccion.addItem("Todo");
		comboPais.addItem("Todo");
		// �rea de Texto
		add(textArea =  new JTextArea(), BorderLayout.CENTER);
		textArea.setEditable(false);
		add(vistaScroll = new JScrollPane(textArea));
		// Bot�n Consulta
		add(btnConsulta = new JButton("Consulta"), BorderLayout.SOUTH);
		btnConsulta.addActionListener(new OyenteBtnConsulta());
		// Agregar Items a Men�s
		agregaMenus = new ConectaBBDD();
		for (int i = 0; i < agregaMenus.getSeccion().size(); i++) {
			comboSeccion.addItem(agregaMenus.getSeccion().get(i));
		}
		for (int i = 0; i < agregaMenus.getPais().size(); i++) {
			comboPais.addItem(agregaMenus.getPais().get(i));
		}
	}
	
	private class OyenteBtnConsulta implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			// Opci�n Todo Todo
			if (comboSeccion.getSelectedItem().equals("Todo") && comboPais.getSelectedItem().equals("Todo")) {
				textArea.setText("");
				try {
					Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
					String ConsultaSql = "SELECT SECCI�N, NOMBREART�CULO, PA�SDEORIGEN FROM PRODUCTOS";
					PreparedStatement miPStatement = miConexion.prepareStatement(ConsultaSql);
					ResultSet miRS = miPStatement.executeQuery();
					while (miRS.next()) {
						textArea.append(miRS.getString("NOMBREART�CULO") + "  |  " + miRS.getString("SECCI�N") + "  |  " + miRS.getString("PA�SDEORIGEN") + "\n");
					}
					// Cerrar flujo
					miConexion.close();
				} catch (SQLException e1) {
					System.out.println("Error en Oyente Opci�n Todo Todo: " + e1.getMessage());
					e1.printStackTrace();
				}
			}
			// Opci�n Secci�n Todo
			else if (!comboSeccion.getSelectedItem().equals("Todo") && comboPais.getSelectedItem().equals("Todo")) {
				textArea.setText("");
				try {
					Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
					String ConsultaSql = "SELECT SECCI�N, NOMBREART�CULO, PA�SDEORIGEN FROM PRODUCTOS WHERE SECCI�N=?";
					PreparedStatement miPStatement = miConexion.prepareStatement(ConsultaSql);
					String argumento = (String) comboSeccion.getSelectedItem();
					miPStatement.setString(1, argumento);
					ResultSet miRS = miPStatement.executeQuery();
					while (miRS.next()) {
						textArea.append(miRS.getString("NOMBREART�CULO") + "  |  " + miRS.getString("SECCI�N") + "  |  " + miRS.getString("PA�SDEORIGEN") + "\n");
					}
					// Cerrar flujo
					miConexion.close();
				} catch (SQLException e1) {
					System.out.println("Error en Oyente Opci�n Secci�n Todo: " + e1.getMessage());
					e1.printStackTrace();
				}
			}
			// Opci�n Todo Pais
			else if (comboSeccion.getSelectedItem().equals("Todo") && !comboPais.getSelectedItem().equals("Todo")) {
				textArea.setText("");
				try {
					Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
					String ConsultaSql = "SELECT SECCI�N, NOMBREART�CULO, PA�SDEORIGEN FROM PRODUCTOS WHERE PA�SDEORIGEN=?";
					PreparedStatement miPStatement = miConexion.prepareStatement(ConsultaSql);
					String argumento = (String) comboPais.getSelectedItem();
					miPStatement.setString(1, argumento);
					ResultSet miRS = miPStatement.executeQuery();
					while (miRS.next()) {
						textArea.append(miRS.getString("NOMBREART�CULO") + "  |  " + miRS.getString("SECCI�N") + "  |  " + miRS.getString("PA�SDEORIGEN") + "\n");
					}
					// Cerrar flujo
					miConexion.close();
				} catch (SQLException e1) {
					System.out.println("Error en Oyente Opci�n Todo Pais: " + e1.getMessage());
					e1.printStackTrace();
				}
			}
			// Opci�n Secci�n Pais
			else if (!comboSeccion.getSelectedItem().equals("Todo") && !comboPais.getSelectedItem().equals("Todo")) {
				textArea.setText("");
				try {
					Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
					String ConsultaSql = "SELECT SECCI�N, NOMBREART�CULO, PA�SDEORIGEN FROM PRODUCTOS WHERE SECCI�N=? AND PA�SDEORIGEN=?";
					PreparedStatement miPStatement = miConexion.prepareStatement(ConsultaSql);
					String argumento1 = (String) comboSeccion.getSelectedItem();
					String argumento2 = (String) comboPais.getSelectedItem();
					miPStatement.setString(1, argumento1);
					miPStatement.setString(2, argumento2);
					ResultSet miRS = miPStatement.executeQuery();
					while (miRS.next()) {
						textArea.append(miRS.getString("NOMBREART�CULO") + "  |  " + miRS.getString("SECCI�N") + "  |  " + miRS.getString("PA�SDEORIGEN") + "\n");
					}
					// Cerrar flujo
					miConexion.close();
				} catch (SQLException e1) {
					System.out.println("Error en Oyente Opci�n Secci�n Pais: " + e1.getMessage());
					e1.printStackTrace();
				}
			}
		}
	}
}
class ConectaBBDD {
	private Connection miConexion;
	private String consultaSeccion, consultaPais;
	private Statement miStatement;
	private ResultSet miResulsetSeccion, miResulsetPais;
	private ArrayList<String> menuSeccion = new ArrayList<String>();
	private ArrayList<String> menuPais = new ArrayList<String>();
	
	public ConectaBBDD() {
		try {
			miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			miStatement = miConexion.createStatement();
			// Items Secci�n
			consultaSeccion = "SELECT DISTINCTROW SECCI�N FROM PRODUCTOS";
			miResulsetSeccion = miStatement.executeQuery(consultaSeccion);
			while (miResulsetSeccion.next()) {
				menuSeccion.add(miResulsetSeccion.getString("SECCI�N"));
			}
			// Items Pa�s
			consultaPais = "SELECT DISTINCT PA�SDEORIGEN FROM PRODUCTOS";
			miResulsetPais = miStatement.executeQuery(consultaPais);
			while (miResulsetPais.next()) {
				menuPais.add(miResulsetPais.getString("PA�SDEORIGEN"));
			}
			// cerrar flujo
			miConexion.close();
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " +  e.getMessage());
			e.printStackTrace();
		}
	}
	public ArrayList<String> getSeccion() {
		return menuSeccion;
	}
	public ArrayList<String> getPais() {
		return menuPais;
	}
}
