package EjerciciosBloque6;

import java.sql.*;

public class _02_ConectaBD_ModificaBBDD {

	public static void main(String[] args) {

		try {
			Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			Statement miSt = miConexion.createStatement();
			
			// CREAR PRODUCTO:
			String agregarBBDD = "INSERT INTO PRODUCTOS (C�DIGOART�CULO, NOMBREART�CULO, PA�SDEORIGEN, PRECIO, SECCI�N) VALUES ('AR42', 'CAMISA HAWAIANA', 'VENEZUELA', 8, 'CONFECCI�N')";
			miSt.executeUpdate(agregarBBDD);
			System.out.println("\nProducto Creado satisfactoriamente!\n");
			
			// ACTUALIZAR PRECIO:
			String actualizarBBDD = "UPDATE PRODUCTOS SET PRECIO = PRECIO*2 WHERE C�DIGOART�CULO = 'AR42' ";
			miSt.executeUpdate(actualizarBBDD);
			System.out.println("\nPrecio Actualizado satisfactoriamente!\n");
			
			// ELIMINAR PRODUCTO:
			String eliminarBBDD = "DELETE FROM PRODUCTOS WHERE C�DIGOART�CULO = 'AR077' ";
			miSt.executeUpdate(eliminarBBDD);
			System.out.println("\nProducto Eliminado satisfactoriamente!\n");
			
			// se cierra flujo
			miConexion.close();
			
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
