package EjerciciosBloque6;

import java.sql.*;

public class _08_ProcedimientoAlmacenado_InsertaClientesPedidos {

	public static void main(String[] args) {
		
		Connection miConexion = null;
		String sqlCliente = "INSERT INTO CLIENTES (C�DIGOCLIENTE, EMPRESA, DIRECCI�N) VALUES ('CT41', 'FOTOSTUDIO ROSSNELL', 'GUAYANITO 4-16')";
		String sqlPedido = "INSERT INTO PEDIDOS (C�DIGOCLIENTE, N�MERODEPEDIDO, FECHADEPEDIDO) VALUES ('CT41', '80', '18/08/2020')";

		try {
			miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			miConexion.setAutoCommit(false);
			Statement miSt = miConexion.createStatement();
			miSt.executeUpdate(sqlCliente);
			System.out.println("Solicitud de Cliente Ingresado Correctamente!");
			miSt.executeUpdate(sqlPedido);
			System.out.println("Solicitud de Pedido Ingresado Correctamente!");
			miConexion.commit();
			miConexion.close();
			
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
			try {
				miConexion.rollback();
			} catch (SQLException e1) {
				System.out.println("Error en RollBack Connection: " + e.getMessage());
				e1.printStackTrace();
			}
		}
	}
}
