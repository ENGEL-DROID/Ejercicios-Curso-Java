package EjerciciosBloque6;

public class _05_MVC_Principal {

	public static void main(String[] args) {

		_05_MVC_Vista miApp = new _05_MVC_Vista();
	}
}
