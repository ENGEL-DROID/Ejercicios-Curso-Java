package EjerciciosBloque6;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JTextArea;

public class _05_MVC_Controlador implements ActionListener {
	
	private _05_MVC_Modelo Conexion;
	private String consultaSql, consultaSeccion, consultaPais, argumento1, argumento2;
	private PreparedStatement miPStatement;
	private ResultSet miResultset;
	private JComboBox seccion, pais;
	private JTextArea areaTxt;
	
	public _05_MVC_Controlador(JComboBox seccion, JComboBox pais, JTextArea areaTxt) {
		Conexion = new _05_MVC_Modelo();
		this.seccion = seccion;
		this.pais = pais;
		this.areaTxt = areaTxt;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		consultaSql = "SELECT * FROM PRODUCTOS WHERE SECCI�N=? AND PA�SDEORIGEN=?";
		consultaSeccion = "SELECT * FROM PRODUCTOS WHERE SECCI�N=?";
		consultaPais = "SELECT * FROM PRODUCTOS WHERE PA�SDEORIGEN=?";
		argumento1 = (String)seccion.getSelectedItem();
		argumento2 = (String)pais.getSelectedItem();	
		
		// Si se ha seleccionado Todo - Todo
		if (seccion.getSelectedItem().equals("Todo") && pais.getSelectedItem().equals("Todo")) {
			areaTxt.setText("");
			try {
				miPStatement = Conexion.getMiConexion().prepareStatement("SELECT * FROM PRODUCTOS");
				miResultset = miPStatement.executeQuery();
				while (miResultset.next()) {
					areaTxt.append(miResultset.getString("NOMBREART�CULO") + " - " + miResultset.getString("SECCI�N") + " - " + miResultset.getString("PA�SDEORIGEN") + "\n");
				}
			} catch (SQLException e1) {
				System.out.println("Error en Consulta Todo - Todo: " + e1.getMessage());
				e1.printStackTrace();
			}
		}
		
		// Si se ha seleccionado Secci�n - Todo
		if (!seccion.getSelectedItem().equals("Todo") && pais.getSelectedItem().equals("Todo")) {
			areaTxt.setText("");
			System.out.println("Selecci�n de Secci�n: " + (String)seccion.getSelectedItem());
			try {
				miPStatement = Conexion.getMiConexion().prepareStatement(consultaSeccion);
				miPStatement.setString(1, argumento1);
				miResultset = miPStatement.executeQuery();
				while (miResultset.next()) {
					areaTxt.append(miResultset.getString("NOMBREART�CULO") + " - " + miResultset.getString("SECCI�N") + " - " + miResultset.getString("PA�SDEORIGEN") + "\n");
				}
			} catch (SQLException e1) {
				System.out.println("Error en Consulta Secci�n - Todo: " + e1.getMessage());
				e1.printStackTrace();
			}
		}
		
		// Si se ha seleccionado Todo - Pa�s
		else if (seccion.getSelectedItem().equals("Todo") && !pais.getSelectedItem().equals("Todo")) {
			areaTxt.setText("");
			System.out.println("Selecci�n de Pa�s: " + (String)pais.getSelectedItem());
			try {
				miPStatement = Conexion.getMiConexion().prepareStatement(consultaPais);
				miPStatement.setString(1, argumento2);
				miResultset = miPStatement.executeQuery();
				while (miResultset.next()) {
					areaTxt.append(miResultset.getString("NOMBREART�CULO") + " - " + miResultset.getString("SECCI�N") + " - " + miResultset.getString("PA�SDEORIGEN") + "\n");
				}
			} catch (SQLException e1) {
				System.out.println("Error en Consulta Todo - Pa�s: " + e1.getMessage());
				e1.printStackTrace();
			}
		}
		
		// Si se ha seleccionado Secci�n - Pa�s
		else if (!seccion.getSelectedItem().equals("Todo") && !pais.getSelectedItem().equals("Todo")) {
			areaTxt.setText("");
			System.out.println("Selecci�n de Secci�n y Pa�s: " + (String)seccion.getSelectedItem() + " - " + (String)pais.getSelectedItem());
			try {
				miPStatement = Conexion.getMiConexion().prepareStatement(consultaSql);
				miPStatement.setString(1, argumento1);
				miPStatement.setString(2, argumento2);
				miResultset = miPStatement.executeQuery();
				while (miResultset.next()) {
					areaTxt.append(miResultset.getString("NOMBREART�CULO") + " - " + miResultset.getString("SECCI�N") + " - " + miResultset.getString("PA�SDEORIGEN") + "\n");
				}
			} catch (SQLException e1) {
				System.out.println("Error en Consulta Secci�n - Pa�s: " + e1.getMessage());
				e1.printStackTrace();
			}
		}
	}
}
