package EjerciciosBloque6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JTextArea;

public class _05_MVC_Modelo {
	
	private Connection miConexion;
	private Statement miStatement;
	private PreparedStatement miPStatement;
	private ResultSet miResultset;
	private String consultaSql, consultaSeccion, consultaPais, argumento1, argumento2;
	
	public _05_MVC_Modelo() {
		try {
			miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			miStatement = miConexion.createStatement();
		
		} catch (SQLException e) {
			System.out.println("Error en Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	// M�todo para Cargar Men� Secci�n
	public void cargarSeccion(JComboBox seccion) {
		try {
			consultaSql = "SELECT DISTINCTROW SECCI�N FROM PRODUCTOS";
			miResultset = miStatement.executeQuery(consultaSql);
			while (miResultset.next()) {
				seccion.addItem(miResultset.getString("SECCI�N"));
			}
		} catch (SQLException e) {
			System.out.println("Error en Cargar Secci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	// M�todo para Cargar Men� Pa�s
	public void cargarPais(JComboBox pais) {
		try {
			consultaSql = "SELECT DISTINCTROW PA�SDEORIGEN FROM PRODUCTOS";
			miResultset = miStatement.executeQuery(consultaSql);
			while (miResultset.next()) {
				pais.addItem(miResultset.getString("PA�SDEORIGEN"));
			}
		} catch (SQLException e) {
			System.out.println("Error en Cargar Pa�s: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	// Getter
	public Connection getMiConexion() {
		return miConexion;
	}
}
