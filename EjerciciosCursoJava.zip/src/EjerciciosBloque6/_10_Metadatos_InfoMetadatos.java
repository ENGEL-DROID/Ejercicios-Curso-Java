package EjerciciosBloque6;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class _10_Metadatos_InfoMetadatos {

	public static void main(String[] args) {

		getMetadata();
		getBBDDInfo();
	}

	// M�todo MetaData Info
	private static void getMetadata() {
		Connection miConexion = null;
		
		try {
			miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			DatabaseMetaData miData = miConexion.getMetaData();
			
			System.out.println("Data Base Product Name: " + miData.getDatabaseProductName());
			System.out.println("Data Base Product Version: " + miData.getDatabaseProductVersion());
			System.out.println("Data Base Driver Name: " + miData.getDriverName());
			System.out.println("Data Base Driver Version: " + miData.getDriverVersion());
			System.out.println("Data Base SQL Keywords: " + miData.getSQLKeywords());
			System.out.println("Data Base URL: " + miData.getURL());
			System.out.println("Data Base URL User Name: " + miData.getUserName());
			
			miConexion.close();
			
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	// M�todo BBDD Info
	private static void getBBDDInfo() {
		Connection miConexion = null;
		try {
			miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas", "root", "");
			DatabaseMetaData miData = miConexion.getMetaData();
			
			// Info de las Tablas
			System.out.println("\nTablas Disponibles en la BBDD:");
			ResultSet miRsData1 = miData.getTables(null, null, null, null);
			while (miRsData1.next()) {
				System.out.println("- " + miRsData1.getString("TABLE_NAME"));
			}
			
			// Info de las Columnas
			System.out.println("\nT�tulos de la Tabla Productos:");
			ResultSet miRsData2 = miData.getColumns(null, null, "PRODUCTOS", null);
			while (miRsData2.next()) {
				System.out.println("- " + miRsData2.getString("COLUMN_NAME"));
			}
			miConexion.close();
			
		} catch (SQLException e) {
			System.out.println("Error de Conecci�n: " + e.getMessage());
			e.printStackTrace();
		}
	}
}

