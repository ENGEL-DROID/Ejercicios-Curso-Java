package EjerciciosBloque3;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class _05_PlantillasPersonalizadas {

	public static void main(String[] args) {

		MarcoPlantillasPersonalizadas marco = new MarcoPlantillasPersonalizadas();
	}
}

class MarcoPlantillasPersonalizadas extends JFrame {
	
	public MarcoPlantillasPersonalizadas() {

		setTitle(" Disposici�n Libre");
		setSize(400, 400);
		setLocationRelativeTo(null);
		
		add(new VentanaPlantillasPersonalizadas());
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class VentanaPlantillasPersonalizadas extends JPanel {
	
	public VentanaPlantillasPersonalizadas() {

		setLayout(new DistribucionPersonalizada());
		
		JLabel txt1 = new JLabel("Nombre");
		JLabel txt2 = new JLabel("Apellido");
		
		JTextField field1 = new JTextField(20);
		JTextField field2 = new JTextField(20);
		
		JButton btn = new JButton("Enviar");
		
		add(txt1);
		add(field1);
		add(txt2);
		add(field2);
		add(btn);
	}
	
	private class DistribucionPersonalizada implements LayoutManager {

		@Override
		public void layoutContainer(Container parent) {
			
			int x = parent.getWidth() / 2;
			int y = 50;

			for (int i=0; i<parent.getComponentCount(); i++) {
				parent.getComponent(i).setBounds(x-100, y, 100, 30);
				x += 100;
				if ((i+1) % 2 == 0) {
					x = parent.getWidth() / 2;
					y += 100;
				} 
			}
		}

		@Override
		public void addLayoutComponent(String name, Component comp) {
			// TODO Auto-generated method stub
		}

		@Override
		public void removeLayoutComponent(Component comp) {
			// TODO Auto-generated method stub
		}

		@Override
		public Dimension preferredLayoutSize(Container parent) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Dimension minimumLayoutSize(Container parent) {
			// TODO Auto-generated method stub
			return null;
		}
	}
}