package EjerciciosBloque3;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Spring;
import javax.swing.SpringLayout;

public class _03_DisposicionMuelle {

	public static void main(String[] args) {
		
		MarcoDisposicionMuelle marco = new MarcoDisposicionMuelle();
	}
}

class MarcoDisposicionMuelle extends JFrame {
	
	public MarcoDisposicionMuelle() {

		setSize(800, 300);
		setTitle("  Disposici�n Muelles");
		setLocationRelativeTo(null);
		
		add(new LaminaDisposicionMuelle());
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class LaminaDisposicionMuelle extends JPanel {
	
	SpringLayout disposicion;
	
	public LaminaDisposicionMuelle() {
		
		setLayout(disposicion =new SpringLayout());

		JButton btn1 = new JButton("Bot�n 1");
		JButton btn2 = new JButton("Bot�n 2");
		JButton btn3 = new JButton("Bot�n 3");
		
		add(btn1);
		add(btn2);
		add(btn3);
		
		Spring muelle = Spring.constant(0, 0, 10);
		Spring muelleFijo = Spring.constant(50);
		
		disposicion.putConstraint(SpringLayout.WEST, btn1, muelle, SpringLayout.WEST, this);
		disposicion.putConstraint(SpringLayout.WEST, btn2, muelleFijo, SpringLayout.EAST, btn1);
		disposicion.putConstraint(SpringLayout.WEST, btn3, muelleFijo, SpringLayout.EAST, btn2);
		disposicion.putConstraint(SpringLayout.EAST, this, muelle, SpringLayout.EAST, btn3);
	}
}