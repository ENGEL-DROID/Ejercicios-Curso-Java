package EjerciciosBloque3;

import java.awt.GridBagLayout;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class _02_DisposicionesBox {

	public static void main(String[] args) {

		MarcoDisposicionesBox marco = new MarcoDisposicionesBox();
	}
}

class MarcoDisposicionesBox extends JFrame {
	
	public MarcoDisposicionesBox() {

		setSize(400, 600);
		setTitle("  Disposiciones Box");
		setLocationRelativeTo(null);
		
		add(new LaminaDisposicionesBox());
		
		pack();
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class LaminaDisposicionesBox extends JPanel {
	
	public LaminaDisposicionesBox() {
		
		Box boxH1 = Box.createHorizontalBox();
		Box boxH2 = Box.createHorizontalBox();
		Box boxH3 = Box.createHorizontalBox();
		
		boxH1.add(Box.createHorizontalStrut(50));
		boxH1.add(new JLabel("Nombre"));
		boxH1.add(Box.createHorizontalStrut(20));
		boxH1.add(new JTextField(20));
		boxH1.add(Box.createHorizontalStrut(50));

		boxH2.add(Box.createHorizontalStrut(50));
		boxH2.add(new JLabel("Email"));
		boxH2.add(Box.createHorizontalStrut(20));
		boxH2.add(new JTextField(20));
		boxH2.add(Box.createHorizontalStrut(50));
		
		boxH3.add(Box.createHorizontalStrut(50));
		boxH3.add(new JButton("Ok"));
		boxH3.add(Box.createGlue());
		boxH3.add(new JButton("Cancelar"));
		boxH3.add(Box.createHorizontalStrut(50));
		
		Box boxV = Box.createVerticalBox();
		
		boxV.add(Box.createVerticalStrut(80));
		boxV.add(boxH1);
		boxV.add(Box.createVerticalStrut(30));
		boxV.add(boxH2);
		boxV.add(Box.createVerticalStrut(30));
		boxV.add(boxH3);
		boxV.add(Box.createVerticalStrut(100));
		
		add(boxV);
	}
}