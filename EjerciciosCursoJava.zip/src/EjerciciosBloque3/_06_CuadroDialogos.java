package EjerciciosBloque3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class _06_CuadroDialogos {

	public static void main(String[] args) {
		
		MarcoCuadroDialogos marco = new MarcoCuadroDialogos();
	}
}

class MarcoCuadroDialogos extends JFrame {
	
	public MarcoCuadroDialogos() {

		setTitle(" Cuadros Di�logos");
		setSize(600, 400);
		setLocationRelativeTo(null);
		
		add(new VentanaCuadroDialogos());
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class VentanaCuadroDialogos extends JPanel {
	
	private JButton btn1, btn2, btn3, btn4;
	
	public VentanaCuadroDialogos() {

		add(btn1 = new JButton("Advertencia"));
		add(btn2 = new JButton("Intro Datos"));
		add(btn3 = new JButton("Confirmar"));
		add(btn4 = new JButton("Selecci�n"));
		
		ClaseOyente oyente = new ClaseOyente();
		
		btn1.addActionListener(oyente);
		btn2.addActionListener(oyente);
		btn3.addActionListener(oyente);
		btn4.addActionListener(oyente);
	}
	
	private class ClaseOyente implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			String tallas[] = {"S","M","L","XL"};

			if (e.getSource() == btn1) JOptionPane.showMessageDialog(VentanaCuadroDialogos.this, "Le advertimos que ...", "Advertencia", 2);
			if (e.getSource() == btn2) JOptionPane.showInputDialog(VentanaCuadroDialogos.this, "Introduzca sus datos");
			if (e.getSource() == btn3) JOptionPane.showConfirmDialog(VentanaCuadroDialogos.this, "Elija una opci�n", "Confirmar", 1);
			if (e.getSource() == btn4) JOptionPane.showOptionDialog(VentanaCuadroDialogos.this, "Seleccione su talla", "Opciones", 1, 1, null, tallas, 0);
		}
	}
}