package EjerciciosBloque3;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class _04_DisposicionLibre {

	public static void main(String[] args) {

		MarcoDisposicionLibre marco = new MarcoDisposicionLibre();
	}
}

class MarcoDisposicionLibre extends JFrame {
	
	public MarcoDisposicionLibre() {

		setTitle(" Disposici�n Libre");
		setSize(400, 500);
		setLocationRelativeTo(null);
		
		add(new VentanaDisposicionLibre());
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class VentanaDisposicionLibre extends JPanel {
	
	public VentanaDisposicionLibre() {

		setLayout(null);
		
		JLabel txt1 = new JLabel("Nombre");
		JLabel txt2 = new JLabel("Apellido");
		
		JTextField field1 = new JTextField(20);
		JTextField field2 = new JTextField(20);
		
		JButton btn = new JButton("Enviar");
		
		add(txt1).setBounds(50, 100, 50, 30);
		add(field1).setBounds(150, 100, 150, 30);
		add(txt2).setBounds(50, 200, 50, 30);
		add(field2).setBounds(150, 200, 150, 30);
		add(btn).setBounds(150, 300, 150, 30);
	}
}