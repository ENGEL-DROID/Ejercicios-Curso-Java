package EjerciciosBloque3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.text.StyledEditorKit;

public class _01_ProcesadorDeTextosFull {

	public static void main(String[] args) {

		MarcoProcesadorTexto miMarco = new MarcoProcesadorTexto();
	}
}

class MarcoProcesadorTexto extends JFrame {
	
	public MarcoProcesadorTexto() {

		setSize(700, 500);
		setTitle("Procesador de Textos");
		setLocationRelativeTo(null);
		
		add(new LaminaProcesadorTexto());
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class LaminaProcesadorTexto extends JPanel {
	
	JPanel laminaSup;
	private JMenuBar barraMenu;
	private JMenu menuFuente, menuEstilo, menuTamanio;
	private JMenuItem fuenteArial, fuenteCourier, fuenteVerdana, estiloNegrita, estiloCursiva, estiloSubrayado;
	private JRadioButtonMenuItem radio12, radio16, radio20, radio24;
	private ButtonGroup radioGrupo = new ButtonGroup();
	private JTextPane textPane;
	private String lorem = "At vero eos et accusamus \nEt iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat. \n \n At vero eos et accusamus \nEt iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat. \n \n";
	private JScrollPane scrollPanel;
	private JPopupMenu popupMenu;
	private JToolBar toolBar;
	private JButton toolBold, toolItalic, toolUnderline, toolBlue, toolGreen, toolRed, toolLeft, toolCenter, toolRight;
	
	public LaminaProcesadorTexto() {
		
		setLayout(new BorderLayout());

		add(laminaSup = new JPanel(), BorderLayout.NORTH);
		
		// ------------------------BARRA MENU---------------------------------
		laminaSup.add(barraMenu = new JMenuBar());
		barraMenu.add(menuFuente = new JMenu("Fuente"));
		barraMenu.add(menuEstilo = new JMenu("Estilo"));
		barraMenu.add(menuTamanio = new JMenu("Tama�o"));
		
		MenuItems items = new MenuItems();
		
		// ------------------------ITEMS FUENTE---------------------------------
		menuFuente.add(items.fuenteArial());
		menuFuente.add(items.fuenteCourier());
		menuFuente.add(items.fuenteVerdana());
		
		// ------------------------ITEMS ESTILO---------------------------------
		menuEstilo.add(items.estiloNegrita());
		menuEstilo.add(items.estiloCursiva());
		menuEstilo.add(items.estiloSubrayado());
		
		// ------------------------ITEMS TAMA�O---------------------------------
		menuTamanio.add(items.radio12());
		menuTamanio.add(items.radio16());
		menuTamanio.add(items.radio20());
		menuTamanio.add(items.radio24());
		radioGrupo.add(radio12);
		radioGrupo.add(radio16);
		radioGrupo.add(radio20);
		radioGrupo.add(radio24);
		
		// ------------------------TEXT PANE---------------------------------
		add(textPane = new JTextPane());
		textPane.setText(lorem);
		textPane.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		add(scrollPanel = new JScrollPane(textPane));
		
		ClaseOyentes oyentes = new ClaseOyentes();
		
		// ------------------------POPUP MENU---------------------------------
		popupMenu = new JPopupMenu();
		
		popupMenu.add(items.fuenteArial());
		popupMenu.add(items.fuenteCourier());
		popupMenu.add(items.fuenteVerdana());
		
		popupMenu.addSeparator();
		popupMenu.add(items.estiloNegrita());
		popupMenu.add(items.estiloCursiva());
		popupMenu.add(items.estiloSubrayado());
		
		popupMenu.addSeparator();
		popupMenu.add(items.radio12());
		popupMenu.add(items.radio16());
		popupMenu.add(items.radio20());
		popupMenu.add(items.radio24());
		radioGrupo.add(radio12);
		radioGrupo.add(radio16);
		radioGrupo.add(radio20);
		radioGrupo.add(radio24);
		
		textPane.setComponentPopupMenu(popupMenu);
		
		add(BarraDeHerramientas(), BorderLayout.WEST);

		ClaseOyentes oyentes2 = new ClaseOyentes();
	}
	
	// -----------------------CLASE OYENTES---------------------------------
	private class ClaseOyentes {
		
		public ClaseOyentes () {
			fuenteArial.addActionListener(new StyledEditorKit.FontFamilyAction(null, "Arial"));
			fuenteCourier.addActionListener(new StyledEditorKit.FontFamilyAction(null, "Courier"));
			fuenteVerdana.addActionListener(new StyledEditorKit.FontFamilyAction(null, "Verdana"));
			
			estiloNegrita.addActionListener(new StyledEditorKit.BoldAction());
			estiloCursiva.addActionListener(new StyledEditorKit.ItalicAction());
			estiloSubrayado.addActionListener(new StyledEditorKit.UnderlineAction());
			
			estiloNegrita.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
			estiloCursiva.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K, InputEvent.CTRL_DOWN_MASK));
			estiloSubrayado.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
			
			radio12.addActionListener(new StyledEditorKit.FontSizeAction(null, 12));
			radio16.addActionListener(new StyledEditorKit.FontSizeAction(null, 16));
			radio20.addActionListener(new StyledEditorKit.FontSizeAction(null, 20));
			radio24.addActionListener(new StyledEditorKit.FontSizeAction(null, 24));
		}
	}
	
	// ---------------------------------------------CLASE ITEMS----------------------------------------------
	private class MenuItems {
		
		public JMenuItem fuenteArial() {return fuenteArial = new JMenuItem("Arial", new ImageIcon("src/images/tipo.png"));}
		public JMenuItem fuenteCourier() {return fuenteCourier = new JMenuItem("Courier", new ImageIcon("src/images/tipo.png"));}
		public JMenuItem fuenteVerdana() {return fuenteVerdana = new JMenuItem("Verdana", new ImageIcon("src/images/tipo.png"));}
		
		public JMenuItem estiloNegrita() {return estiloNegrita = new JMenuItem("Negrita", new ImageIcon("src/images/style.png"));}
		public JMenuItem estiloCursiva() {return estiloCursiva = new JMenuItem("Cursiva", new ImageIcon("src/images/style.png"));}
		public JMenuItem estiloSubrayado() {return estiloSubrayado = new JMenuItem("Subrayado", new ImageIcon("src/images/style.png"));}
		
		public JRadioButtonMenuItem radio12() {return radio12 = new JRadioButtonMenuItem("12", new ImageIcon("src/images/fontSize.png"));}
		public JRadioButtonMenuItem radio16() {return radio16 = new JRadioButtonMenuItem("16", new ImageIcon("src/images/fontSize.png"));}
		public JRadioButtonMenuItem radio20() {return radio20 = new JRadioButtonMenuItem("20", new ImageIcon("src/images/fontSize.png"));}
		public JRadioButtonMenuItem radio24() {return radio24 = new JRadioButtonMenuItem("24", new ImageIcon("src/images/fontSize.png"));}
	}
	
	// ---------------------------------------------TOOLBAR----------------------------------------------
	private JToolBar BarraDeHerramientas() {
		
		toolBar = new JToolBar("ToolBar");
		toolBar.setOrientation(1);
		
		toolBar.addSeparator();
		toolBar.add(toolBold = new JButton(new ImageIcon("src/images/bold.png")));
		toolBar.add(toolItalic = new JButton(new ImageIcon("src/images/italic.png")));
		toolBar.add(toolUnderline = new JButton(new ImageIcon("src/images/underline.png")));
		toolBar.addSeparator();
		toolBar.add(toolBlue = new JButton(new ImageIcon("src/images/azul.png")));
		toolBar.add(toolGreen = new JButton(new ImageIcon("src/images/verde.png")));
		toolBar.add(toolRed = new JButton(new ImageIcon("src/images/rojo.png")));
		toolBar.addSeparator();
		toolBar.add(toolLeft = new JButton(new ImageIcon("src/images/izqda.png")));
		toolBar.add(toolCenter = new JButton(new ImageIcon("src/images/centro.png")));
		toolBar.add(toolRight = new JButton(new ImageIcon("src/images/dcha.png")));
		
		toolBold.addActionListener(new StyledEditorKit.BoldAction());
		toolItalic.addActionListener(new StyledEditorKit.ItalicAction());
		toolUnderline.addActionListener(new StyledEditorKit.UnderlineAction());

		toolBlue.addActionListener(new StyledEditorKit.ForegroundAction(null, Color.BLUE));
		toolGreen.addActionListener(new StyledEditorKit.ForegroundAction(null, Color.GREEN.darker()));
		toolRed.addActionListener(new StyledEditorKit.ForegroundAction(null, Color.RED));
		
		toolLeft.addActionListener(new StyledEditorKit.AlignmentAction(null, 0));
		toolCenter.addActionListener(new StyledEditorKit.AlignmentAction(null, 1));
		toolRight.addActionListener(new StyledEditorKit.AlignmentAction(null, 2));

		return toolBar;
	}
}