package EjerciciosBloque4;

public class _12_Banco_Sin_Sincronizar {

	public static void main(String[] args) {
		
		BancoPipe miBanco = new BancoPipe();
		
//		miBanco.transferencias();
		
		while (true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			miBanco.transferencias();
		}
	}
}


class BancoPipe extends Thread {
	
	private double cantidadTransaccion, saldoTotalBanco;
	private double saldoComprobado = 0;
	private int cuentaOrigen, cuentaDestino, cuentaRandom;
	private double[] cuentas = new double[100];
	
	public BancoPipe() {

		for (int i = 0; i < cuentas.length; i++) {
			cuentas[i] = 2000;
			saldoTotalBanco += cuentas[i];
		} 
		System.out.println("Saldo Total Banco bucle for: " + saldoTotalBanco);
		
	}
	
	public void transferencias() {
		
		cantidadTransaccion = Math.random()*2000;
		
		cuentaOrigen = (int) ((Math.random())*100);
		cuentaDestino = (int) ((Math.random())*100);
		
		if (cuentas[cuentaOrigen] > cantidadTransaccion) {
			cuentas[cuentaOrigen] -= cantidadTransaccion;
			cuentas[cuentaDestino] += cantidadTransaccion;
		} else {
			System.out.printf("\nTransferencia Cancelada! | Monto solicitado: %1.2f�, Cuenta Origen nro: %d, Cuenta Destino nro: %d, Saldo Total Banco: %1.2f�", cantidadTransaccion, cuentaOrigen, cuentaDestino, saldoTotalBanco);                                                                 
			System.out.printf("\nSaldo Cuenta Origen: %1.2f�, Saldo Cuenta Destino: %1.2f�", cuentas[cuentaOrigen], cuentas[cuentaDestino]);
			System.out.println("\nHilo nro: " + getName());
		}
		
		System.out.printf("\nTransferencia exitosa! | Monto transferido: %1.2f�, Cuenta Origen nro: %d, Cuenta Destino nro: %d, Saldo Total Banco: %1.2f�", cantidadTransaccion, cuentaOrigen, cuentaDestino, saldoTotalBanco);                                                                 
		
		for (int i = 0; i < cuentas.length; i++) {
			saldoComprobado += cuentas[i];
		}
		System.out.printf("\nSaldo Nuevo Cuenta Origen: %1.2f�, Saldo Nuevo Cuenta Destino: %1.2f�, Saldo Nuevo Comprobado Banco: %1.2f�", cuentas[cuentaOrigen], cuentas[cuentaDestino], saldoComprobado);
		System.out.println("\nHilo nro: " + getName());
		saldoComprobado = 0;
	}
}