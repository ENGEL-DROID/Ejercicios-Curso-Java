package EjerciciosBloque4;

import java.util.GregorianCalendar;

public class _09_MetodosGenericos {

	public static void main(String[] args) {

		// ----------------------------ARRAY DE NOMBRES--------------------------------------
		System.out.println("ARRAY DE NOMBRES:");
		
		String[] nombres = {"Pepito Fulano", "Marconi Lusejo", "Escarlata Dientreto", "Antonie Lexpury", "Dawal Espertoo"};
		
		ClaseMetodosGenericos metodos = new ClaseMetodosGenericos();
		
		System.out.println(metodos.cantidadElementos(nombres));

		System.out.println("Elemento menor: " + metodos.valorMenor(nombres));
		
		// ----------------------------ARRAY DE FECHAS--------------------------------------
		System.out.println("\nARRAY DE FECHAS:");
		
		GregorianCalendar[] fechas = new GregorianCalendar[4];
		fechas[0] = new GregorianCalendar(2005, 3, 14);
		fechas[1] = new GregorianCalendar(2010, 8, 20);
		fechas[2] = new GregorianCalendar(2014, 10, 3);
		fechas[3] = new GregorianCalendar(2003, 1, 25);
		
		ClaseMetodosGenericos fechasM = new ClaseMetodosGenericos();
		
		System.out.println(fechasM.cantidadElementos(fechas));

		System.out.println("Elemento menor: " + fechasM.valorMenor(fechas).getTime());
		
		// ----------------------------ARRAY DE EMPLEADOS--------------------------------------
		System.out.println("\nARRAY DE EMPLEADOS:");
		
		Empleado[] misEmpleados = new Empleado[6];
		misEmpleados[0] = new Empleado("Asprilla", 5600, 1997, 3, 25);
		misEmpleados[1] = new Empleado("Higuita", 5600, 1997, 3, 25);
		misEmpleados[2] = new Empleado("Valderrama", 5600, 1997, 3, 25);
		misEmpleados[3] = new Empleado("Rinc�n", 5600, 1997, 3, 25);
		misEmpleados[4] = new Empleado("James", 5600, 1997, 3, 25);
		misEmpleados[5] = new Empleado("Falcao", 5600, 1997, 3, 25);
		
		ClaseMetodosGenericos jugadores = new ClaseMetodosGenericos();
		
		System.out.println(jugadores.cantidadElementos(misEmpleados));
	}
}

// ------------------------CLASE CON M�TODOS GEN�RICOS-----------------------------------
class ClaseMetodosGenericos {
	
	public static <T> String cantidadElementos(T[] obj) {
		return "El array tiene: " +  obj.length + " elementos.";
	}
	
	public static <T extends Comparable> T valorMenor(T[] array) {
		T menor = array[0];
		for (int i = 0; i < array.length; i++) {
			if (menor.compareTo(array[i]) > 0) {
				menor = array[i];
			}
		}
		return menor;
	}
}