package EjerciciosBloque4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class _04_LeyendoEscribiendoBytes {

	public static void main(String[] args) {
		
		byte[] imagen = new byte[338022];
		
		// ----------------------------LECTURA DE BYTES-------------------------------
		File file = new File("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/kitty.jpg");

		try {
			// abro flujo
			FileInputStream archivo = new FileInputStream(file);
			
			// Usado al principio para saber la cantidad de bytes del archivo
//			int contador = 0;
//				while (archivo.read() != -1) {
//					contador++;
//				}
//				System.out.println(contador);
			
			try {
				for (int i = 0; i < imagen.length; i++) {
					imagen[i] = (byte) archivo.read();
					System.out.println(imagen[i]);
				}
				
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
			// ciero flujo
			try {
				archivo.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		// ----------------------------ESCRITURA DE BYTES-------------------------------
		File fileCopy = new File("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/kitty_copy.jpg");
		
		try {
			// abro flujo
			FileOutputStream archivoOut = new FileOutputStream(fileCopy);
			
			for (int i = 0; i < imagen.length; i++) {
				try {
					archivoOut.write(imagen[i]);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			// cierro flujo
			try {
				archivoOut.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
