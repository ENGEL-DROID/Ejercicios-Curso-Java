package EjerciciosBloque4;

import java.io.File;

public class _01_AccesoFicheros {

	public static void main(String[] args) {

		File ruta = new File("C:\\Users\\DELL-OPTIPLEX-ENGEL\\Desktop\\Curso de Java\\EjerciciosCursoJava\\src");
		
		System.out.println("\nExiste el fichero?: " + ruta.exists());
		
		System.out.println("\nRuta: " + ruta.getAbsolutePath());
		
		File[] archivos = ruta.listFiles();
		
		System.out.println("\nCantidad total de archivos en la ruta: " + archivos.length + "\n");
		
		for (int i = 0; i < archivos.length; i++) {
			
			if (archivos[i].isDirectory()) {
				
				String[] subCarpetas = archivos[i].list();
				
				if (subCarpetas.length > 0) {
					System.out.println("Carpeta Padre: " + archivos[i].getName() + " | Archivos:");
				} else {
					System.out.println("Carpeta Padre: " + archivos[i].getName() + " | Archivos: No tiene.");
				}
				for (int j = 0; j < subCarpetas.length; j++) {
					System.out.println(subCarpetas[j]);
				}
			} 
			System.out.println("\n");
		}
	}
}
