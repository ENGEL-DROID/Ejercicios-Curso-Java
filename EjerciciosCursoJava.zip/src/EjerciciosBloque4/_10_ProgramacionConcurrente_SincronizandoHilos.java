package EjerciciosBloque4;

public class _10_ProgramacionConcurrente_SincronizandoHilos {

	public static void main(String[] args) {

		ClaseHilosUno uno = new ClaseHilosUno();
		ClaseHilosDos dos = new ClaseHilosDos(uno);
		ClaseHilosDos tres = new ClaseHilosDos(dos);
		
		uno.start();
		dos.start();
		tres.start();
	}
}

// ---------------------------CLASE HILOS UNO---------------------------------------
class ClaseHilosUno extends Thread {
	
	public void run() {
		for (int i = 0; i < 15; i++) {
			System.out.println("Hilo nro: " + (i+1) + ", Hilo Id: " + getId() + ", Hilo nombre: " + getName() + ", Hilo estado: " + getState() + ", Hilo actual: " + Thread.currentThread());
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

//---------------------------CLASE HILOS DOS---------------------------------------
class ClaseHilosDos extends Thread {
	
	private Thread hilo;
	
	public ClaseHilosDos(Thread hilo) {
		this.hilo = hilo;
	}
	
	public void run() {
		
		try {
			hilo.join();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		
		for (int i = 0; i < 15; i++) {
			System.out.println("Hilo nro: " + (i+1) + ", Hilo Id: " + getId() + ", Hilo nombre: " + getName() + ", Hilo estado: " + getState() + ", Hilo actual: " + Thread.currentThread());
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}