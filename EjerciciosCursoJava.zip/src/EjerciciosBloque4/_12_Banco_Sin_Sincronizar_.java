package EjerciciosBloque4;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class _12_Banco_Sin_Sincronizar_ {

	public static void main(String[] args) {
		
		BancoPipex miBanco = new BancoPipex();
		
		for (int i=0; i<100; i++) {
			Thread t = new Thread(miBanco);
			t.start();
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class BancoPipex extends Thread implements Runnable {
	
	private double cantidadTransaccion;
	private double saldoTotalBanco = 0;
	private int cuentaOrigen, cuentaDestino;
	private double[] cuentas = new double[100];
	private ReentrantLock bloqueo = new ReentrantLock();
	private Condition condicion = bloqueo.newCondition();
	
	public BancoPipex() {

		for (int i = 0; i < cuentas.length; i++) {
			cuentas[i] = 2000;
		}
	}
	
	public double SaldoTotalBanco() {
		for (int i = 0; i < cuentas.length; i++) {
			saldoTotalBanco += cuentas[i];
		}
		return saldoTotalBanco;
	}
	
	public void run() {
		
		bloqueo.lock();

		try {
			
			Thread.sleep(100);
			
			cantidadTransaccion = Math.random()*2000;
			
			cuentaOrigen = (int) ((Math.random())*100);
			cuentaDestino = (int) ((Math.random())*100);
			
			if (cuentas[cuentaOrigen] < cantidadTransaccion) {
				
				System.out.println("\nHILO ESPERANDO..........................");
				System.out.printf("Transferencia a la espera de saldo suficiente! | Monto solicitado: %1.2f�, Cuenta Origen nro: %d, Cuenta Destino nro: %d", cantidadTransaccion, cuentaOrigen, cuentaDestino);                                                                 
				System.out.printf("\nSaldo Cuenta Origen: %1.2f�, Saldo Cuenta Destino: %1.2f�", cuentas[cuentaOrigen], cuentas[cuentaDestino]);
				System.out.println("\nHilo nro: " + getName() + " " + currentThread());
				
				condicion.await();
				
				if (cuentas[cuentaOrigen] >= cantidadTransaccion) {
					System.out.print("\nHILO LIBERADO!!!!!!!!!!!!!!!!!!!!!!!!!");
				} 
				
			} else {
				
				cuentas[cuentaOrigen] -= cantidadTransaccion;
				cuentas[cuentaDestino] += cantidadTransaccion;
				
				System.out.printf("\nTransferencia exitosa! | Monto transferido: %1.2f�, Cuenta Origen nro: %d, Cuenta Destino nro: %d, Saldo Total Banco: %1.2f�", cantidadTransaccion, cuentaOrigen, cuentaDestino, SaldoTotalBanco());                                                                 
				
				System.out.printf("\nSaldo Nuevo Cuenta Origen: %1.2f�, Saldo Nuevo Cuenta Destino: %1.2f�", cuentas[cuentaOrigen], cuentas[cuentaDestino]);
				System.out.println("\nHilo nro: " + getName() + " " + currentThread());
				
				saldoTotalBanco = 0;
			}
			
			condicion.signalAll();

		}
		catch (InterruptedException e) {
			e.printStackTrace();
			
		} finally {
			bloqueo.unlock();
		}
	}
}