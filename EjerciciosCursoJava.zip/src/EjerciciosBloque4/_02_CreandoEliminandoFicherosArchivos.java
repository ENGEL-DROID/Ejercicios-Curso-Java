package EjerciciosBloque4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

public class _02_CreandoEliminandoFicherosArchivos {

	public static void main(String[] args) {

		// ---------------------------CREA DIRECTORIO NUEVO----------------------------------
		File ruta = new  File("C:"+File.separator+"Users"+File.separator+"DELL-OPTIPLEX-ENGEL"+File.separator+"Desktop"+File.separator+"Curso de Java"+File.separator+"EjerciciosCursoJava"+File.separator+"src"+File.separator+"servidor"+File.separator+"Directorio Nuevo");

		ruta.mkdir();
		
		if (ruta.exists()) {
			System.out.println("\nDirectorio Nuevo creado con �xito! =) \n");
			JOptionPane.showMessageDialog(null, "Directorio Nuevo creado con �xito!");
		} else {
			System.out.println("\nDirectorio Nuevo NO exite! :( \n");
			JOptionPane.showMessageDialog(null, "Directorio Nuevo NO exite!");
		}
		
		// ---------------------------CREA ARCHIVO NUEVO----------------------------------
		File rutaArchivo = new  File("C:"+File.separator+"Users"+File.separator+"DELL-OPTIPLEX-ENGEL"+File.separator+"Desktop"+File.separator+"Curso de Java"+File.separator+"EjerciciosCursoJava"+File.separator+"src"+File.separator+"servidor"+File.separator+"Directorio Nuevo"+File.separator+"Archivo Nuevo.txt");
		
		try {
			rutaArchivo.createNewFile();
			if (rutaArchivo.exists()) {
				System.out.println("\nArchivo Nuevo creado con �xito! =) \n");
				JOptionPane.showMessageDialog(null, "Archivo Nuevo creado con �xito!");
			} else {
				System.out.println("\nEl archivo nuevo No ha podido ser creado :( \n");
				JOptionPane.showMessageDialog(null, "El archivo nuevo No ha podido ser creado");
			}
		} catch (IOException e) {
			System.out.println("Ha surgido un error al intentar crear el archivo nuevo");
			e.printStackTrace();
		}
		
		// ---------------------------INSTANCIAS----------------------------------
		EscribirEnArchivo escribir = new EscribirEnArchivo(rutaArchivo);
		
		try {
			LeerDeArchivo leer = new LeerDeArchivo(rutaArchivo);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// ---------------------------ELIMINAR ARCHIVO----------------------------------
		int confirmar = JOptionPane.showConfirmDialog(null, "�Deseas eliminar el archivo?");
		
		if (confirmar == 0) {
			rutaArchivo.delete();
		} else {
			JOptionPane.showMessageDialog(null, "Archivo conservado");
			System.out.println("\n \nArchivo conservado");
			return;
		}
		
		// ---------------------------REVISAR SI EXISTE EL ARCHIVO----------------------------------
		if (!rutaArchivo.exists()) {
			JOptionPane.showMessageDialog(null, "Archivo eliminado con �xito");
			System.out.println("\n \nArchivo eliminado con �xito");
		} 
	}
}

// ---------------------------CLASE PARA ESCRIBIR EN ARCHIVO NUEVO----------------------------------
class EscribirEnArchivo {
	File ruta;
	String parrafo = "Lorem ipsum dolor sit amet consectetur adipiscing elit vel sociosqu, vitae id pretium ultricies volutpat semper sodales pulvinar et metus, praesent fames nam porta justo dui sem donec. Facilisi magnis leo dictum a lacinia rutrum per faucibus, hac auctor nisl tempor elementum quis non molestie pellentesque, risus ultricies placerat potenti porta pulvinar donec. Tincidunt ultrices nulla laoreet nostra quam luctus pharetra dictumst donec, vulputate lacinia urna torquent accumsan sodales eu phasellus per, varius eleifend condimentum ligula interdum tristique magna natoque.";
	
	public EscribirEnArchivo(File ruta) {
		this.ruta = ruta;
		
		try {
			// abro flujo
			FileWriter escribir = new FileWriter(ruta);
			escribir.write(parrafo);
			// cierro flujo
			escribir.close();
			JOptionPane.showMessageDialog(null, "Texto escrito con �xito");
			System.out.println("TEXTO ESCRITO CON �XITO");
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}

class LeerDeArchivo {
	File ruta;
	
	public LeerDeArchivo(File ruta) throws IOException {
		this.ruta = ruta;
		try {
			// abro flujo
			FileReader leer = new FileReader(ruta);
			int nro = 0;
			JOptionPane.showMessageDialog(null, "Texto le�do con �xito");
			System.out.println("\nTEXTO LE�DO:");
			
			while (nro != -1) {
				nro = leer.read();
				char letra = (char) nro;
				
				if (nro != -1) {
					System.out.print(letra);
				}
			}
			// cierro flujo
			leer.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
	}
}