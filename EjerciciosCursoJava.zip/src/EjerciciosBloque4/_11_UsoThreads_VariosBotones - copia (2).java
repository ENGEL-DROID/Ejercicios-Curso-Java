package EjerciciosBloque4;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class _11_UsoThreads_VariosBotones {

	public static void main(String[] args) {

		MarcoPelotas marco = new MarcoPelotas();
		marco.setVisible(true);
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

// --------------------------MARCO PRINCIPAL-------------------------------------
class MarcoPelotas extends JFrame {
	
	private JButton btnPlay1, btnPlay2, btnPlay3, btnStop1, btnStop2, btnStop3;
	private int marcoX, marcoY;
	private MoverPelotas moverPelotas = new MoverPelotas();
	
	public MarcoPelotas() {
		
		setSize(600, 400);
		setTitle(" Hilos Pelotas");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		
		marcoX = this.getWidth();
		marcoY = this.getHeight() - 70;
		
		// -----------------------L�MINA PELOTAS---------------------------------
		add(moverPelotas, BorderLayout.CENTER);
		moverPelotas.setBackground(new Color(204, 255, 204));
		
		// -----------------------L�MINA BOTONES---------------------------------
		JPanel laminaBotones = new JPanel();
		laminaBotones.setBackground(new Color(204, 204, 255));
		add(laminaBotones, BorderLayout.SOUTH);
		laminaBotones.add(btnPlay1 = new JButton("Play 1"));
		laminaBotones.add(btnPlay2 = new JButton("Play 2"));
		laminaBotones.add(btnPlay3 = new JButton("Play 3"));
		laminaBotones.add(btnStop1 = new JButton("Stop 1"));
		laminaBotones.add(btnStop2 = new JButton("Stop 2"));
		laminaBotones.add(btnStop3 = new JButton("Stop 3"));
		
		btnPlay1.setBackground(new Color(255, 255, 204));
		btnPlay2.setBackground(new Color(255, 255, 204));
		btnPlay3.setBackground(new Color(255, 255, 204));
		btnStop1.setBackground(new Color(255, 204, 255));
		btnStop2.setBackground(new Color(255, 204, 255));
		btnStop3.setBackground(new Color(255, 204, 255));
		
		// -----------------------OYENTES ACCIONES---------------------------------
		AccionesBotones oyente = new AccionesBotones();
		btnPlay1.addActionListener(oyente);
		btnPlay2.addActionListener(oyente);
		btnPlay3.addActionListener(oyente);
		btnStop1.addActionListener(oyente);
		btnStop2.addActionListener(oyente);
		btnStop3.addActionListener(oyente);
	}
	
	// ----------------------------CLASE ACCIONES------------------------------------
	class AccionesBotones implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
//			if (e.getSource() == btnPlay1) System.out.println("marcoX: " + marcoX + ", marcoY: " + marcoY);
		}
	}
	
	// -------------------------CLASE DIBUJAR PELOTAS-----------------------------------
	class LaminaPelotas {
		private int x, y, xw, yh, dx, dy;
		
		public LaminaPelotas() {
			dx = 1;
			dy = 1;
			xw = 25;
			yh = 25;
		}
		
		public void pintarPelotas(Graphics g) {
			x += dx;
			y += dy;
			// si las distancias x-y de la bola son mayores que el marco, entonces ir restando posiciones 
			if ((x+xw) >= marcoX) {
				x = marcoX - xw;
				dx = -dx;
			}			
			if ((y+yh) >= marcoY) {
				y = marcoY - yh;
				dy = -dy;
			}
			// si las distancias x-y de la bola son menores que el marco, entonces ir sumando posiciones 
			if (x < 1) {
				x = 1;
				dx = -dx;
			}			
			if (y < 1) {
				y = 1;
				dy = -dy;
			}

			g.setColor(new Color(255, 0, 102));
			g.fillOval(x, y, xw, yh);
		}
	}
	
	// -------------------------CLASE MOVER PELOTAS-----------------------------------
	class MoverPelotas extends JPanel implements Runnable {
		
		LaminaPelotas laminaPelotas;
		Thread hilo;
		
		public MoverPelotas() {
			
			laminaPelotas = new LaminaPelotas();
			hilo = new Thread();
			
			System.out.println("Hilo actual: " + hilo.currentThread() + ", | Nombre: " + hilo.getName() + " | Est� activado?: " + hilo.isAlive() + " | Interrumpido?: " + hilo.isInterrupted());
		}

		@Override
		public void run() {
			
//			hilo.start();
			try {
				hilo.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		public void paintComponent(Graphics g) {       
			super.paintComponent(g);
			laminaPelotas.pintarPelotas(g);
		      repaint();
		      try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

//-------------------------CLASE MOVER PELOTAS-----------------------------------
class ClaseHilos {
	
	Runnable runnable = new MoverPelotas();
}














