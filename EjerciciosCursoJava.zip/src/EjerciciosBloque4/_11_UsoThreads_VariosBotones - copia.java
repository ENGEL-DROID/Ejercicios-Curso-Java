package EjerciciosBloque4;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class _11_UsoThreads_VariosBotones {

	public static void main(String[] args) {

		MarcoPelotas marco = new MarcoPelotas();
		marco.setVisible(true);
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}

// --------------------------MARCO PRINCIPAL-------------------------------------
class MarcoPelotas extends JFrame {
	
	private JButton btnPlay1, btnPlay2, btnPlay3, btnStop1, btnStop2, btnStop3;
	private int marcoX, marcoY;
	private LaminaPelotas laminaPelotax = new LaminaPelotas();
	private Rectangle2D rectangulo = laminaPelotax.getBounds();
	private int minX = (int) rectangulo.getMinX();
	private int minY = (int) rectangulo.getMinY();
	
	public MarcoPelotas() {
		
		setSize(600, 400);
		setTitle(" Hilos Pelotas");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		
		marcoX = this.getWidth();
		marcoY = this.getHeight();
		
		// -----------------------L�MINA PELOTAS---------------------------------
		laminaPelotax.setBackground(new Color(204, 255, 204));
		add(laminaPelotax, BorderLayout.CENTER);
		
		// -----------------------L�MINA BOTONES---------------------------------
		JPanel laminaBotones = new JPanel();
		laminaBotones.setBackground(new Color(204, 204, 255));
		add(laminaBotones, BorderLayout.SOUTH);
		laminaBotones.add(btnPlay1 = new JButton("Play 1"));
		laminaBotones.add(btnPlay2 = new JButton("Play 2"));
		laminaBotones.add(btnPlay3 = new JButton("Play 3"));
		laminaBotones.add(btnStop1 = new JButton("Stop 1"));
		laminaBotones.add(btnStop2 = new JButton("Stop 2"));
		laminaBotones.add(btnStop3 = new JButton("Stop 3"));
		
		// -----------------------OYENTES ACCIONES---------------------------------
		AccionesBotones oyente = new AccionesBotones();
		btnPlay1.addActionListener(oyente);
		btnPlay2.addActionListener(oyente);
		btnPlay3.addActionListener(oyente);
		btnStop1.addActionListener(oyente);
		btnStop2.addActionListener(oyente);
		btnStop3.addActionListener(oyente);
	}
	
	// ----------------------------CLASE ACCIONES------------------------------------
	class AccionesBotones implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

//			if (e.getSource() == btnPlay1) System.out.println("marcoX: " + marcoX + ", marcoY: " + marcoY);
//			if (e.getSource() == btnPlay1) System.out.println("maxX: " + maxX + ", maxY: " + maxY);
		}
	}
	
	// -------------------------CLASE DIBUJAR PELOTAS-----------------------------------
	class LaminaPelotas extends JPanel {
		
		private int x, y, xw, yh, dx, dy;
		
		public LaminaPelotas() {
			
			dx = 1;
			dy = 1;
			xw = 15;
			yh = 15;
		}
		
		public void paint(Graphics g) {
			
			x += dx;
			y += dy;

			// si las distancias x-y de la bola son mayores que el marco, entonces ir restando posiciones 
			if ((x+xw) >= marcoX) {
				x = marcoX - xw;
				dx = -dx;
			}			
			if ((y+yh) >= marcoY) {
				y = marcoY - yh;
				dy = -dy;
			}
			
			// si las distancias x-y de la bola son menores que el marco, entonces ir sumando posiciones 
			if (x < minX) {
				x = minX;
				dx = -dx;
			}			
			if (y < minY) {
				y = minY;
				dy = -dy;
			}
			
//			System.out.println("dx: " + dx + "   dy: " + dy + "   x: " + x + "   y: " + y);

			g.fillOval(x, y, xw, yh);
//			g.fillOval(x+100, y+100, xw, yh);
//			g.fillOval(x+200, y+200, xw, yh);
			
			Thread hilo = new Thread(new Runnable() {

				@Override
				public void run() {
					repaint();
				}
			});
			
			try {
				hilo.sleep(1);
				hilo.start();
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}






























