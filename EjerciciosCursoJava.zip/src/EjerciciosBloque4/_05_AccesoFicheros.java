package EjerciciosBloque4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;
import java.util.GregorianCalendar;

public class _05_AccesoFicheros {

	public static void main(String[] args) {
		
		// -----------------------OBJETO INSTANCIAS-------------------------------
		Jefe jefe = new Jefe("Carmen Noguera", 3500, 1998, 2, 3);
		jefe.setIncentivo(1000);

		Empleado[] empleados = new Empleado[4];
		empleados[0] = new Empleado("Jos� Ruco", 2500, 2005, 7, 15);
		empleados[1] = jefe;
		empleados[2] = new Empleado("Mar�a Pati�o", 1500, 2004, 5, 20);
		empleados[3] = new Empleado("Arc�ngel Molina", 1500, 2007, 3, 5);
		
		// -----------------------EXPORTAR OBJETO-------------------------------
		try {
			// abro flujo
			FileOutputStream  rutaOut = new FileOutputStream ("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/data.txt");
			ObjectOutputStream objetoOut;
			
			try {
				// abro flujo
				objetoOut = new ObjectOutputStream(rutaOut);
				objetoOut.writeObject(empleados);
				
				// cierro flujo
				objetoOut.close();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			// cierro flujo
			try {
				rutaOut.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		// -----------------------IMPORTAR OBJETO-------------------------------
		try {
			// se abre flujo
			FileInputStream rutaIn = new FileInputStream ("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/data.txt");
			
			try {
				// se abre flujo
				ObjectInputStream objetoIn = new ObjectInputStream(rutaIn);
				
				try {
					Empleado[] empleadosIn = (Empleado[]) objetoIn.readObject();
					
					for (int i = 0; i < empleadosIn.length; i++) {
						System.out.println(empleadosIn[i].dameData());
					}
					
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				
				// se cierra flujo
				objetoIn.close();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		
			// se cierra flujo
			try {
				rutaIn.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}

//---------------------------CLASE EMPLEADO---------------------------------------
class Empleado implements Serializable  {
	
	// se crea la huella �nica del programa
	private static final long serialVersionUID = 1L;

	private String nombre;
	private double sueldo;
	private Date fechaContrato;
	
	public Empleado(String n, double s, int anio, int mes, int dia) {
		nombre = n;
		sueldo = s;
		GregorianCalendar calendario = new GregorianCalendar(anio, mes-1, dia);
		fechaContrato = calendario.getTime();
	}
	
	public String getNombre() {
		return nombre;
	}

	public double getSueldo() {
		return sueldo;
	}

	public Date getFechaContrato() {
		return fechaContrato;
	}

	
	public void subirSueldo(double porcentaje) {
		double aumento = sueldo * porcentaje / 100;
		sueldo += aumento;
	}
	
	public String dameData() {
		return "El Nombre es: " + nombre + ", y su sueldo es de $" + sueldo + ". Fecha de contrato: " + fechaContrato;
	}
}

 // ---------------------------CLASE JEFE---------------------------------------
class Jefe extends Empleado {
	
	// se crea la huella �nica del programa
	private static final long serialVersionUID = 1L;
	
	private double incentivo;
	
	public Jefe(String n, double s, int anio, int mes, int dia) {
		super(n, s, anio, mes, dia);
		incentivo = 0;
	}
	
	public double getSueldo() {
		double sueldoBase = super.getSueldo();
		return sueldoBase + incentivo;
	}
	
	public void setIncentivo(double b) {
		incentivo = b;
	}
	
	public String dameData() {
		return super.toString() + ". Incentivo: " + incentivo;
	}
}