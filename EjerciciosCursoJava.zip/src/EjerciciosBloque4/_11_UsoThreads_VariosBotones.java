package EjerciciosBloque4;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import EjerciciosBloque4.MarcoPelotas.DibujarPelota;

public class _11_UsoThreads_VariosBotones {

	public static void main(String[] args) {

		MarcoPelotas marco = new MarcoPelotas();
		marco.setVisible(true);
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

// --------------------------MARCO PRINCIPAL-------------------------------------
class MarcoPelotas extends JFrame {
	
	private JButton btnPlay1, btnPlay2, btnPlay3, btnStop1, btnStop2, btnStop3;
	private int marcoX, marcoY;
	private LaminaxPelotas lamina = new LaminaxPelotas();
	private Thread hilo1, hilo2, hilo3;
	
	public MarcoPelotas() {
		
		setSize(600, 400);
		setTitle(" Hilos Pelotas");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		
		marcoX = this.getWidth();
		marcoY = this.getHeight() - 70;
		
//		// -----------------------L�MINA PELOTAS---------------------------------
		lamina.setBackground(new Color(204, 255, 204));
		add(lamina, BorderLayout.CENTER);
		
		// -----------------------L�MINA BOTONES---------------------------------
		JPanel laminaBotones = new JPanel();
		laminaBotones.setBackground(new Color(204, 204, 255));
		add(laminaBotones, BorderLayout.SOUTH);
		laminaBotones.add(btnPlay1 = new JButton("Play 1"));
		laminaBotones.add(btnPlay2 = new JButton("Play 2"));
		laminaBotones.add(btnPlay3 = new JButton("Play 3"));
		laminaBotones.add(btnStop1 = new JButton("Stop 1"));
		laminaBotones.add(btnStop2 = new JButton("Stop 2"));
		laminaBotones.add(btnStop3 = new JButton("Stop 3"));
		
		btnPlay1.setBackground(new Color(255, 255, 204));
		btnPlay2.setBackground(new Color(255, 255, 204));
		btnPlay3.setBackground(new Color(255, 255, 204));
		btnStop1.setBackground(new Color(255, 204, 255));
		btnStop2.setBackground(new Color(255, 204, 255));
		btnStop3.setBackground(new Color(255, 204, 255));
		
		// -----------------------OYENTES ACCIONES---------------------------------
		AccionesBotones oyente = new AccionesBotones();
		btnPlay1.addActionListener(oyente);
		btnPlay2.addActionListener(oyente);
		btnPlay3.addActionListener(oyente);
		btnStop1.addActionListener(oyente);
		btnStop2.addActionListener(oyente);
		btnStop3.addActionListener(oyente);
	}
	
	// ----------------------------CLASE ACCIONES------------------------------------
	class AccionesBotones implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (e.getSource() == btnPlay1) LanzarHilos(e);
			if (e.getSource() == btnPlay2) LanzarHilos(e);
			if (e.getSource() == btnPlay3) LanzarHilos(e);
			
			if (e.getSource() == btnStop1) DetenerHilos(e);
			if (e.getSource() == btnStop2) DetenerHilos(e);
			if (e.getSource() == btnStop3) DetenerHilos(e);
		}
	}
	
	// -------------------------M�TODO LANZAR HILOS------------------------------------
	public void LanzarHilos(ActionEvent e) {
		
		DibujarPelota pelotaNew = new DibujarPelota();
		lamina.addjuntar(pelotaNew);
		
		Runnable runner = new ClaseRunnable(pelotaNew, lamina);
		
		if (e.getSource().equals(btnPlay1)) {
			hilo1 = new Thread(runner);
			hilo1.start();
		} else if (e.getSource().equals(btnPlay2)) {
			hilo2 = new Thread(runner);
			hilo2.start();
		} else if (e.getSource().equals(btnPlay3)) {
			hilo3 = new Thread(runner);
			hilo3.start();
		}
	}
	
	// -------------------------M�TODO DETENER HILOS-----------------------------------
	public void DetenerHilos(ActionEvent e) {
		
		if (e.getSource().equals(btnStop1)) {
			hilo1.interrupt();
		} else if (e.getSource().equals(btnStop2)) {
			hilo2.interrupt();
		} else if (e.getSource().equals(btnStop3)) {
			hilo3.interrupt();
		}
	}
	
	// -------------------------CLASE DIBUJAR PELOTA-----------------------------------
	class DibujarPelota extends JPanel {
		private int x, y, xw, yh, dx, dy;
		
		public DibujarPelota() {
			dx = 1;
			dy = 1;
			xw = 35;
			yh = 35;
		}
		
		public void pintarPelotas() {
			x += dx;
			y += dy;
			// si las distancias x-y de la bola son mayores que el marco, entonces ir restando posiciones 
			if ((x+xw) >= marcoX) {
				x = marcoX - xw;
				dx = -dx;
			}			
			if ((y+yh) >= marcoY) {
				y = marcoY - yh;
				dy = -dy;
			}
			// si las distancias x-y de la bola son menores que el marco, entonces ir sumando posiciones 
			if (x < 1) {
				x = 1;
				dx = -dx;
			}			
			if (y < 1) {
				y = 1;
				dy = -dy;
			}
		}
		
		public Ellipse2D getShape(){
			return new Ellipse2D.Double(x,y,xw,yh);
		}
	}
	
	// -------------------------CLASE MOVER PELOTAS-----------------------------------
	class LaminaxPelotas extends JPanel {
		
		ArrayList<DibujarPelota> pelotas = new ArrayList<MarcoPelotas.DibujarPelota>();
		
		public void addjuntar(DibujarPelota b) {
			pelotas.add(b);
		}
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
				g2.setColor(new Color(255, 0, 102));
			for(DibujarPelota p: pelotas)
				g2.fill(p.getShape());
		}
	}
}

// ---------------------------CLASE RUNNABLE-------------------------------------------
class ClaseRunnable implements Runnable {
	
	private DibujarPelota unaPelota;
	private Component unComponente;
	
	public ClaseRunnable(DibujarPelota unaPelota, Component unComponente) {
		this.unaPelota = unaPelota;
		this.unComponente = unComponente;
	}

	@Override
	public void run() {

		System.out.println("Estado del hilo al iniciar: " + Thread.currentThread().isInterrupted());
		
		// �ste bucle while es el responsable del efecto de movimiento
		while (!Thread.currentThread().isInterrupted()) {
			
			unaPelota.pintarPelotas();
			unComponente.paint(unComponente.getGraphics());
			
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Estado del hilo al finalizar: " + Thread.currentThread().isInterrupted());
	}
}