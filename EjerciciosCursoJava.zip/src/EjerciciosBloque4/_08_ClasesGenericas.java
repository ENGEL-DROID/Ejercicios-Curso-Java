package EjerciciosBloque4;

public class _08_ClasesGenericas {

	public static void main(String[] args) {

		// --------------INSTANCIA CLASE GEN�RICA TIPO STRING----------------
		ParejaOcho<String> empleados = new ParejaOcho<String>();
		empleados.setVariable("Diego de la Rua");
		System.out.println(empleados.getVariable());
		
		// --------------INSTANCIA CLASE GEN�RICA TIPO EMPLEADO----------------
		EmpleadoOcho empleado = new EmpleadoOcho("Amanda Greick", 35, 3500);
		ParejaOcho<EmpleadoOcho> empleadoPareja = new ParejaOcho<EmpleadoOcho>();
		empleadoPareja.setVariable(empleado);
		ParejaOcho.imprimeVariable(empleadoPareja);
		
		// -----------INSTANCIA CLASE GEN�RICA TIPO PERSONA-------------------
		Persona persona = new Persona("Alejandro Arteaza");
		ParejaOcho<Persona> empleadoPersona = new ParejaOcho<Persona>();
		empleadoPersona.setVariable(persona);
		System.out.println("Gen�rico Tipo Persona: " + empleadoPersona.getVariable());
	} 
}

// ---------------------------CLASE EMPLEADO-------------------------------
class EmpleadoOcho {
	
	private String nombre;
	private int edad;
	private double salario;
	
	public EmpleadoOcho(String nombre, int edad, double salario) {
		this.nombre = nombre;
		this.edad = edad;
		this.salario = salario;
	}
	
	public String dameData() {
		return "Nombre: " + nombre + ", Edad: " + edad + "a�os, Salario: " + salario + "�";
	}
}

// -------------------------CLASE GEN�RICA PAREJA-------------------------------
class ParejaOcho<T>  {
	
	private T variable;
	
	public ParejaOcho() {
		variable = null;
	}
	
	public void setVariable(T mod) {
		this.variable = mod;
	}
	
	public T getVariable() {
		return variable;
	}
	
	public static void imprimeVariable(ParejaOcho<? extends EmpleadoOcho> obj) {
		EmpleadoOcho variable = obj.getVariable();
		System.out.print("Gen�rico Tipo Empleado: ");
		System.out.println(variable);
	}
}

// -------------------------CLASE PERSONA-------------------------------
class Persona  {
	
	private String nombre;
	
	public Persona(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}
	
}