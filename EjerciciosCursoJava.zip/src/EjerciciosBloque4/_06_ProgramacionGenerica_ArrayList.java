package EjerciciosBloque4;

import java.io.File;

public class _06_ProgramacionGenerica_ArrayList {

	public static void main(String[] args) {

		// ----------------1ERA INSTANCIA-------------------
		ClaseGenerica instancia = new ClaseGenerica(6);
		instancia.ElementoNuevo("Pedro");
		instancia.ElementoNuevo("Mar�a");
		instancia.ElementoNuevo("Juan");
		instancia.ElementoNuevo("Rosita");
		instancia.ElementoNuevo("Diego");
		instancia.ElementoNuevo("Anna");
		
		System.out.println(instancia.dameElemento(2));
		System.out.println(instancia.dameElemento(4));
		
		// ----------------2DA INSTANCIA-------------------
		File ruta = new File("C:\\Users\\DELL-OPTIPLEX-ENGEL\\Desktop\\Curso de Java\\EjerciciosCursoJava\\src");
		
		ClaseGenerica instancia2 = new ClaseGenerica(1);
		instancia2.ElementoNuevo(ruta);
		
		System.out.println(instancia2.dameElemento(0));
	}
}

// ----------------------CLASE CON UN OBJETO GEN�RICO----------------------
class ClaseGenerica {
	
	private Object[] array;
	private int tamanio = 0;
	
	public ClaseGenerica(int tamanio) {
		array = new Object[tamanio];
	}
	
	public Object dameElemento(int elemento) {
		return array[elemento];
	}
	
	public void ElementoNuevo(Object nuevo) {
		array[tamanio] = nuevo;
		tamanio++;
	}
}