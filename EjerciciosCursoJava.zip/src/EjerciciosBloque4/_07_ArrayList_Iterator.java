package EjerciciosBloque4;

import java.util.ArrayList;
import java.util.Iterator;

public class _07_ArrayList_Iterator {

	public static void main(String[] args) {

		// -------------------INSTANCIAR EL ARRAYLIST------------------------------------
		ArrayList<EmpleadoClase> misEmpleados = new ArrayList<EmpleadoClase>();
		
		// ---------------ASEGURAR UN TAMA�O DEL ARRAYLIST---------------------------------
		misEmpleados.ensureCapacity(11);
		
		// ----------------AGREGAR ELEMENTOS AL ARRAYLIST----------------------------------
		misEmpleados.add(0, new EmpleadoClase("Diego", 38, 7800));
		misEmpleados.add(1, new EmpleadoClase("Martha", 28, 2800));
		misEmpleados.add(2, new EmpleadoClase("Rebecca", 32, 4800));
		misEmpleados.add(3, new EmpleadoClase("Elain", 48, 5800));
		misEmpleados.add(4, new EmpleadoClase("Willinton", 35, 1800));
		misEmpleados.add(5, new EmpleadoClase("Anne", 30, 2800));
		
		// ---------------------RECORTAR EL ARRAYLIST------------------------------------
		misEmpleados.trimToSize();

		// ---------------------TAMA�O DEL ARRAYLIST------------------------------------
		System.out.println("\nCantidad de elementos en el ArrayList: " + misEmpleados.size());
		
		// ---------------------REEMPLAZAR UN ELEMENTO------------------------------------
		misEmpleados.set(0, new EmpleadoClase("Juan", 42, 3500));
		
		// ---------------------IMPRIMIR UN ELEMENTO------------------------------------
		System.out.println("\nEmpleado nro 3: " + misEmpleados.get(3).dameDatos() + "\n");
		
		// -----------------IMPRIMIR TODOS LOS ELEMENTOS------------------------------------
		for (int i = 0; i < misEmpleados.size(); i++) {
			System.out.println("Empleado nro " + (i+1) + " : " + misEmpleados.get(i).dameDatos());
		}
		
		// ------------------------------ITERATOR-------------------------------------------
		System.out.println("\nDatos obtenidos por el Iterator:");
		
		Iterator<EmpleadoClase> iterador = misEmpleados.iterator();
		
		while (iterador.hasNext()) {
			// OJO: se debe crear un objeto de tipo clase para poder recorrer y evitar errores
			EmpleadoClase empleadoIterator = iterador.next();
			
			System.out.println(empleadoIterator.dameDatos());
			
			// ------------------ELIMINAR UN EMPLEADO POR SU NOMBRE------------------------------
			if (empleadoIterator.dameNombre().equals("Willinton")) {
				iterador.remove();
			} 
		}
		
		// ---------------CONVERTIR ARRAYLIST EN ARRAY NORMAL--------------------------------
		EmpleadoClase[] nuevoArray = new EmpleadoClase[misEmpleados.size()];
		misEmpleados.toArray(nuevoArray);
		
		// -----------------------IMPRIMIR ARRAY NORMAL-----------------------------------
		System.out.println("\nArrayList convertido a Array Normal:");
		
		for (int i = 0; i < nuevoArray.length; i++) {
			System.out.println("Empleado: " + nuevoArray[i].dameDatos());
		}
	}
}

// --------------------CLASE EMPLEADO---------------------
class EmpleadoClase {
	
	private String nombre;
	private int edad;
	private double salario;
	
	public EmpleadoClase(String nombre, int edad, double salario) {
		this.nombre = nombre;
		this.edad = edad;
		this.salario = salario;
	}
	
	public String dameNombre() {
		return nombre;
	}
	
	public String dameDatos() {
		return "Nombre: " + nombre + ", Edad: " + edad + ", Salario: " + salario + "�";
	}
}