package EjerciciosBloque4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class _03_LeyendoEscribiendoBuffer {

	public static void main(String[] args) {

		LeerTexto leer = new LeerTexto();
		
		EscribirTexto escribir = new EscribirTexto();
		
		AgregarTexto agregar = new AgregarTexto();
		
		LeerTextoBuffer leerBuffer = new LeerTextoBuffer();
		
		EscribirTextoBuffer escribirBuffer = new EscribirTextoBuffer();
		
		AgregarTextoBuffer agregarBuffer = new AgregarTextoBuffer();

	}
}


// -------------------------CLASES SIN BUFFER------------------------------------

// -----------------------CLASE PARA LEER TEXTO------------------------------------
class LeerTexto {
	
	public LeerTexto() {
		File ruta = new File("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/archivo1.txt");
		int nro = 0;
		char letra;
		
		try {
			// abro flujo
			FileReader lectura = new FileReader(ruta);
			System.out.println("\nTEXTO LE�DO: \n");
			
			while (nro != -1) {
				nro = lectura.read();
				letra = (char) nro;
				System.out.print(letra);
			}
			System.out.println("");
			// cierro flujo
			lectura.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

// ----------------------CLASE PARA ESCRIBIR TEXTO----------------------------------
class EscribirTexto {
	
	public EscribirTexto() {
		File ruta = new File("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/archivo2.txt");
		String texto = "Nor again is there anyone who loves or pursues or desires to obtain pain of itself.";
		
		try {
			// abro flujo
			FileWriter escritura = new FileWriter(ruta);
			escritura.write(texto);
			// cierro flujo
			escritura.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

// ----------------------CLASE PARA AGREGAR TEXTO----------------------------------
class AgregarTexto {
	
	public AgregarTexto() {
		File ruta = new File("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/archivo2.txt");
		String texto = "\n \nQui dolorem ipsum, quia dolor sit amet consectetur adipisci velit, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat voluptatem.";
		
		try {
			// abro flujo
			FileWriter escritura = new FileWriter(ruta, true);
			escritura.write(texto);
			// cierro flujo
			escritura.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}


// -------------------------CLASES CON BUFFER------------------------------------

// ---------------------CLASE PARA LEER TEXTO CON BUFFER------------------------------------
class LeerTextoBuffer {
	
	public LeerTextoBuffer() {
		File ruta = new File("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/archivo1_Buffer.txt");
		int nro = 0;
		char letra;
		
		try {
			// abro flujo
			FileReader lectura = new FileReader(ruta);
			BufferedReader buffer = new BufferedReader(lectura);
			
			String leido = "";
			System.out.println("\n \nTEXTO LE�DO BUFFER: \n");
			
			while (leido != null) {
				leido = buffer.readLine();
				if (leido != null) System.out.println(leido);
			}
			// cierro flujo
			lectura.close();
			buffer.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

// ------------------CLASE PARA ESCRIBIR TEXTO CON BUFFER----------------------------------
class EscribirTextoBuffer {
	
	public EscribirTextoBuffer() {
		File ruta = new File("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/archivo2_Buffer.txt");
		String texto = "Argumus again is there estratus who lorus or pursues or desires to obtain pain of itself.";
		
		try {
			// abro flujo
			FileWriter escritura = new FileWriter(ruta);
			BufferedWriter buffer = new BufferedWriter(escritura);
			
			buffer.write(texto);
			
			// cierro flujo
//			escritura.close();  // �ste flujo no se puede cerrar para permitir el buffer
			buffer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

// -------------------CLASE PARA AGREGAR TEXTO CON BUFFER----------------------------------
class AgregarTextoBuffer {
	
	public AgregarTextoBuffer() {
		File ruta = new File("C:/Users/DELL-OPTIPLEX-ENGEL/Desktop/Curso de Java/EjerciciosCursoJava/src/servidor/archivo2_Buffer.txt");
		String texto = "\n \nAmet estimulatum adipisci verdinum, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat esporiatum.";
		
		try {
			// abro flujo
			FileWriter escritura = new FileWriter(ruta, true);
			BufferedWriter buffer = new BufferedWriter(escritura);
			
			buffer.write(texto);
			
			// cierro flujo
//			escritura.close();  // �ste flujo no se puede cerrar para permitir el buffer
			buffer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}