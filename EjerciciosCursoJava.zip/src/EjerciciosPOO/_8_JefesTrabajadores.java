package EjerciciosPOO;

interface Jefe {
	
	public void setDesicion(String desicion);
}


interface Trabajadores {
	
	double salarioBase = 1500;
	
	public void setBono(double bono);
}