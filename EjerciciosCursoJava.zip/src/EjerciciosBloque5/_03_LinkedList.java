package EjerciciosBloque5;

import java.util.LinkedList;
import java.util.ListIterator;

public class _03_LinkedList {

	public static void main(String[] args) {

		LinkedList<String> nombres = new LinkedList<String>();
		
		nombres.add("Dayana");
		nombres.add("Alejandra");
		nombres.add("Rebecca");
		nombres.add("Carolina");
		nombres.add("Andrea");
		nombres.add("Luisana");
		nombres.add("Mariana");
		
		System.out.println("\nTama�o de la colecci�n: la colecci�n tiene " + nombres.size() + " elementos:\n");
		
		for (String nombre : nombres) {
			System.out.println(nombre);
		}
		
		System.out.println("\nAgregar elemento en la posici�n 2 con un ListIterator:");
		
		ListIterator<String> iterador = nombres.listIterator();
		
		iterador.next();
		iterador.add("Roxana");
		
		for (String nombre : nombres) {
			System.out.println(nombre);
		}
	}
}