package EjerciciosBloque5;

import java.util.LinkedList;
import java.util.ListIterator;

public class _04_LinkedList_Enlazada {

	public static void main(String[] args) {

		LinkedList<String> paises = new LinkedList<String>();
		
		paises.add("Argentina");
		paises.add("Per�");
		paises.add("Paraguay");
		paises.add("Colombia");
		paises.add("Venezuela");
		paises.add("Ecuador");
		paises.add("Chile");
		
		LinkedList<String> capitales = new LinkedList<String>();
		
		capitales.add("Buenos Aires");
		capitales.add("Lima");
		capitales.add("Asunci�n");
		capitales.add("Bogot�");
		capitales.add("Caracas");
		capitales.add("Quito");
		capitales.add("Santiago");
		
		// -----------------AGREGAR CAPITALES A LA COLECCI�N PA�SES----------------
		System.out.println("\nCapitales agregadas a colecci�n pa�ses:");
		ListIterator<String> iteradorCapitales = capitales.listIterator();
		ListIterator<String> iteradorPaises = paises.listIterator();
		
		while (iteradorPaises.hasNext()) {
			if (iteradorCapitales.hasNext()) {
			iteradorPaises.next();
			iteradorPaises.add(iteradorCapitales.next());
			}
		}
		
		for (String data : paises) {
			System.out.println(data);
		}
		
		// --------------------ELIMINAR CAPITALES PARES----------------------
		System.out.println("\nCapitales restantes:");
		iteradorCapitales = capitales.listIterator();
		
		while (iteradorCapitales.hasNext()) {
			iteradorCapitales.next();
			if (iteradorCapitales.hasNext()) {
				iteradorCapitales.next();
				iteradorCapitales.remove();
			}
		}
		
		for (String capital : capitales) {
			System.out.println(capital);
		}
		
		// --------------ELIMINAR CAPITALES RESTANTES DE LA COLECCI�N PA�SES-----------------
		System.out.println("\nColecci�n paises sin capitales restantes:");
		
		paises.removeAll(capitales);
		
		for (String pais : paises) {
			System.out.println(pais);
		}
	}
}