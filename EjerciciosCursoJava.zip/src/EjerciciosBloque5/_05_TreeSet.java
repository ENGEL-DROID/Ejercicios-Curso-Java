package EjerciciosBloque5;

import java.util.Comparator;
import java.util.TreeSet;

public class _05_TreeSet {

	public static void main(String[] args) {

		TreeSet<String> nombres = new TreeSet<String>();
		
		nombres.add("Mar�a");
		nombres.add("Fernanda");
		nombres.add("Bertha");
		nombres.add("Danna");
		nombres.add("Xiomara");
		nombres.add("Daniela");
		
		System.out.println(nombres);

		// -------------------COLECCI�N ART�CULOS-------------------------
		System.out.println("\nColecci�n de art�culos ordenados por el n�mero");
		
		Articulo articulo1 = new Articulo(1001, "Ventilador");
		Articulo articulo2 = new Articulo(1002, "Aspirador");
		Articulo articulo3 = new Articulo(1003, "Televisor");
		Articulo articulo4 = new Articulo(1004, "Radio");
		Articulo articulo5 = new Articulo(1005, "Calentador");
		Articulo articulo6 = new Articulo(1006, "Batidor");
		
		TreeSet<Articulo> articulos = new TreeSet<Articulo>();
		
		articulos.add(articulo4);
		articulos.add(articulo2);
		articulos.add(articulo3);
		articulos.add(articulo6);
		articulos.add(articulo1);
		articulos.add(articulo5);
		
		for (Articulo articulo : articulos) {
			System.out.println(articulo.getDescripcion());
		}
		
		// ----------------NUEVA INSTANCIA ART�CULO SIN PAR�METROS-------------------------
		System.out.println("\nArt�culos ordenados por la descripci�n:");
		
		Articulo articuloComp = new Articulo();
		
		TreeSet<Articulo> articulos2 = new TreeSet<Articulo>(articuloComp);
		
		articulos2.add(articulo6);
		articulos2.add(articulo5);
		articulos2.add(articulo3);
		articulos2.add(articulo1);
		articulos2.add(articulo2);
		articulos2.add(articulo4);
		
		for (Articulo articulo : articulos2) {
			System.out.println(articulo.getDescripcion());
		}
		
		// -----------------------------NUEVA COLECCI�N-----------------------------------
		System.out.println("\nArt�culos con clase interna ordenados por la descripci�n:");
		
		TreeSet<Articulo> articulos3 = new TreeSet<Articulo>(new Comparator<Articulo>() {
				@Override
				public int compare(Articulo o1, Articulo o2) {
					return o1.getSoloDescripcion().compareTo(o2.getSoloDescripcion());
				}
			}
			);
		
		articulos3.add(articulo2);
		articulos3.add(articulo4);
		articulos3.add(articulo3);
		articulos3.add(articulo1);
		articulos3.add(articulo6);
		articulos3.add(articulo5);
		
		for (Articulo articulo : articulos3) {
			System.out.println(articulo.getDescripcion());
		}
	}
}

// -------------------CLASE ART�CULO-------------------------
class Articulo implements Comparable<Articulo>, Comparator<Articulo> {
	private int nro;
	private String descripcion;
	
	public Articulo(int nro, String descripcion) {
		this.nro = nro;
		this.descripcion = descripcion;
	}
	
	public Articulo() {
		
	}
	
	public String getDescripcion() {
		return "N�mero del art�culo: " + nro + ", Descripci�n: " + descripcion;
	}
	
	public String getSoloDescripcion() {
		return  descripcion;
	}

	// ----------------M�TODO DE COMPARABLE---------------------
	@Override
	public int compareTo(Articulo obj) {
		return nro - obj.nro;
	}
	
	// ----------------M�TODO DE COMPARATOR---------------------
	@Override
	public int compare(Articulo obj1, Articulo obj2) {
		return obj1.descripcion.compareTo(obj2.descripcion);
	}
}