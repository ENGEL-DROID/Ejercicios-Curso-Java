package EjerciciosBloque5;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class _07_Sockets_Servidor {

	public static void main(String[] args) {

		MarcoServidor marco = new MarcoServidor();
	}
}
// ----------------------MARCO VENTANA UI--------------------------
class MarcoServidor extends JFrame {
	
	private int screenX, screenY, xCliente, yCliente, xMarco, yMarco;
	
	public MarcoServidor() {
		xMarco = 300;
		yMarco = 400;
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		screenX = (int) screenSize.getWidth();
		screenY = (int) screenSize.getHeight();
		xCliente = (screenX/2) + xMarco;
		yCliente = (screenY/2) - (yMarco + 100);
		setBounds(xCliente, yCliente, xMarco, yMarco);
		
		setLayout(new BorderLayout());
		add(new LaminaEspacioS(), BorderLayout.NORTH);
		add(new LaminaServidor(), BorderLayout.CENTER);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

//----------------------L�MINA ESPACIO VAC�O--------------------------
class LaminaEspacioS extends JPanel {
	private JLabel espacio;
	public LaminaEspacioS() {
		setBackground(new Color(204, 255, 204));
		add(espacio = new JLabel("   "));
	}
}

//----------------------L�MINA VENTANA UI--------------------------
class LaminaServidor extends JPanel {
	
	private JLabel titulo;
	private JTextArea chat;
	private JScrollPane vistaScroll;
	
	public LaminaServidor() {
		//----------------------UI--------------------------
		setBackground(new Color(204, 255, 204));
		add(titulo = new JLabel(":::SERVIDOR:::"));
		add(chat = new JTextArea(18,26));
		chat.setLineWrap(true);
		chat.setEnabled(false);
		add(vistaScroll = new JScrollPane(chat));
		
		RecibirData	recibirData = new RecibirData();
	}
	
	//----------------------RECIBIR DATA--------------------------
	public class RecibirData implements Runnable {
		
		private String mensaje, nick, ip;
		private Thread hilo = new Thread(this);  // NOTA: el hilo siempre debe apuntar al entorno ejem: this
		private ArrayList<PaqueteData> listaUsuarios;
		
		public RecibirData() {
			listaUsuarios = new ArrayList<PaqueteData>();
			hilo.start();
		}

		@Override
		public void run() {
			
			try {
				System.out.println("Entr� al Run");
				// se crea enchufe servidor
				ServerSocket enchufeServer = new ServerSocket(9999);
				//
				PaqueteData paqueteIn = new PaqueteData(mensaje, nick, ip);
				
				while (true) {
					
					// se abre el enchufe servidor
					Socket enchufeIn = enchufeServer.accept();
					// 
					ObjectInputStream flujoIn = new ObjectInputStream(enchufeIn.getInputStream());
					// 
					paqueteIn = (PaqueteData) flujoIn.readObject();
					// 
					mensaje = paqueteIn.getMensaje();
					nick = paqueteIn.getNick();
					ip = paqueteIn.getIp();
					
					// se cierran enchufes y flujos
//					enchufeServer.close();  // NOTA: el enchufe servidor NO se debe cerrar nunca!!!
					enchufeIn.close();
					flujoIn.close();
					
					if (!mensaje.equals("onlinex")) {
						//----------------------------ACCI�N LOCAL------------------------------
						chat.append("\n" + nick.toUpperCase() + ": " + mensaje);
						
						//----------------------------ENVIAR DATA------------------------------
						// se abre enchufe
						Socket enchufeOut = new Socket(ip, 9090);
						// se abre flujo
						ObjectOutputStream flujoOut = new ObjectOutputStream(enchufeOut.getOutputStream());
						flujoOut.writeObject(paqueteIn);
						
						// se cierran enchufes y flujos
						enchufeOut.close();
						flujoOut.close();
						
					} else {
						//-------------ALMACENAR Y ENVIAR SE�AL USUARIO CONECTADO-----------------
						listaUsuarios.add(paqueteIn);
						
						// se abre enchufe
						Socket enchufeOut = new Socket(ip, 9090);
						// se abre flujo
						ObjectOutputStream flujoOut = new ObjectOutputStream(enchufeOut.getOutputStream());
						flujoOut.writeObject(paqueteIn);
						
						// se cierran enchufes y flujos
						enchufeOut.close();
						flujoOut.close();
						
					}
				}
				
			} catch (IOException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}
}