package EjerciciosBloque5;

import java.util.HashSet;
import java.util.Iterator;

public class _02_Set_HashSet {

	public static void main(String[] args) {

		Cliente cliente1 = new Cliente("Adri�n L�pez", 1001, 35000);
		Cliente cliente2 = new Cliente("Juli�n Andrade", 1002, 15000);
		Cliente cliente3 = new Cliente("Karina Parada", 1003, 25000);
		Cliente cliente4 = new Cliente("Martha Ram�rez", 1004, 45000);
		Cliente cliente5 = new Cliente("Eustoquio Rol�n", 1005, 38000);
		Cliente cliente6 = new Cliente("Jos� Contreras", 1006, 23000);
		
		// ------------------------CREAR LA COLECCI�N-------------------------------------
		HashSet<Cliente> clientes = new HashSet<Cliente>();
		
		clientes.add(cliente1);
		clientes.add(cliente2);
		clientes.add(cliente3);
		clientes.add(cliente4);
		clientes.add(cliente5);
		clientes.add(cliente6);
		
		for (Cliente cliente : clientes) {
			System.out.println("Nombre del cliente: " + cliente.getNombre() + ", Nro de Cuenta: " + cliente.getNroCuenta() + ", Saldo: " + cliente.getSaldo());
		}
		
		// ---------------------AGREGAR CLIENTE DUPLICADO---------------------------------
		System.out.println("\nColecci�n con cliente duplicado:");
		
		Cliente cliente7 = new Cliente("Karina Parada", 1003, 25000);
		
		clientes.add(cliente7);
		
		for (Cliente cliente : clientes) {
			System.out.println("Nombre del cliente: " + cliente.getNombre() + ", Nro de Cuenta: " + cliente.getNroCuenta() + ", Saldo: " + cliente.getSaldo());
		}
		
		// --------------------IMPRIMIR NOMBRE CON ITERATOR--------------------------------
		System.out.println("\nNombres impresos con iterator:");
		
		Iterator<Cliente> iterador = clientes.iterator();
		
		while (iterador.hasNext()) {
			System.out.println("Cliente: " +  iterador.next().getNombre());
		}
		
		// --------------------ELIMINAR UN CLIENTE CON ITERATOR--------------------------------
		System.out.println("\nCliente Eustoquio eliminado con iterator:");
		
		iterador = clientes.iterator();
		while (iterador.hasNext()) {
			
			if (iterador.next().getNombre().equals("Eustoquio Rol�n")) {
				iterador.remove();
			}
		}
		
		iterador = clientes.iterator();
		while (iterador.hasNext()) {
			System.out.println("Cliente: " +  iterador.next().getNombre());
		}
	}
}

// --------------------CLASE CLIENTE--------------------------------
class Cliente {
	
	private String nombre;
	private int nroCuenta;
	private double saldo;
	
	public Cliente(String nombre, int nroCuenta, double saldo) {
		this.nombre = nombre;
		this.nroCuenta = nroCuenta;
		this.saldo = saldo;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setNroCuenta(int nroCuenta) {
		this.nroCuenta = nroCuenta;
	}
	
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public String getNombre() {
		return nombre;
	}

	public int getNroCuenta() {
		return nroCuenta;
	}

	public double getSaldo() {
		return saldo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + nroCuenta;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cliente other = (Cliente) obj;
		if (nroCuenta != other.nroCuenta)
			return false;
		return true;
	}
}