package EjerciciosBloque5;

public class _01_HashCode_Equals {

	public static void main(String[] args) {

		Libro libro1 = new Libro("El Mendigo", "Arturo Prieto", 2005, 1001);
		Libro libro2 = new Libro("El Mendigo", "Arturo Prieto", 2005, 1001);
		
		if (libro1.equals(libro2)) {
			System.out.println("Los dos libros son Iguales");
		} else {
			System.out.println("Los dos libros son Diferentes");
		}
		
		System.out.println("HasCode Libro 1: " + libro1.hashCode() + ", HasCode Libro 2: " + libro2.hashCode());
	}
}

class Libro {
	private String titulo, autor;
	private int anio, ISBN;
	
	public Libro(String titulo, String autor, int anio, int ISBN) {
		this.titulo = titulo;
		this.autor = autor;
		this.anio = anio;
		this.ISBN = ISBN;
	}
	
	public String getData() {
		return "T�tulo del libro: " + titulo + ", Autor: " + autor + ", A�o: " + anio + ", ISBN: " + ISBN;
	}
	
//	public boolean equals(Libro obj) {
//		if (this.ISBN == obj.ISBN) {
//			return true;
//		} else {
//			return false;
//		}
//	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ISBN;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Libro other = (Libro) obj;
		if (ISBN != other.ISBN)
			return false;
		return true;
	}
}