package EjerciciosBloque5;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class _07_Sockets_Cliente {

	public static void main(String[] args) {
		
		MarcoChat marco = new MarcoChat();
	}
}
// ----------------------MARCO VENTANA UI--------------------------
class MarcoChat extends JFrame {
	
	private int screenX, screenY, xCliente, yCliente, xMarco, yMarco;
	
	public MarcoChat() {
		xMarco = 300;
		yMarco = 400;
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		screenX = (int) screenSize.getWidth();
		screenY = (int) screenSize.getHeight();
		xCliente = (screenX/2) + xMarco;
		yCliente = (screenY/2) - 100;
		setBounds(xCliente, yCliente, xMarco, yMarco);
		
		setLayout(new BorderLayout());
		add(new LaminaEspacio(), BorderLayout.NORTH);
		add(new LaminaChat(), BorderLayout.CENTER);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

//----------------------L�MINA ESPACIO VAC�O--------------------------
class LaminaEspacio extends JPanel {
	private JLabel espacio;
	public LaminaEspacio() {
		setBackground(new Color(204, 255, 204));
		add(espacio = new JLabel("   "));
	}
}

//----------------------L�MINA VENTANA UI--------------------------
class LaminaChat extends JPanel {
	
	private String nickUsuario;
	private JLabel nickTitulo, nick, contactosTitulo;
	private JComboBox contactos;
	private JTextArea chat;
	private JScrollPane vistaScroll;
	private JTextField entrada;
	private JButton btnEnviar;
	private String myIp;
	
	public LaminaChat() {
		
		RecibirData dataIn = new RecibirData();
		
		//----------------------UI--------------------------
		setBackground(new Color(204, 255, 204));
		add(nickTitulo = new JLabel("nick: "));
		nickUsuario = JOptionPane.showInputDialog("Ingrese su nick");
		add(nick = new JLabel(nickUsuario.toUpperCase()));
		add(contactosTitulo = new JLabel(" |  contactos: "));
		add(contactos = new JComboBox());
		add(chat = new JTextArea(14,20));
		chat.setLineWrap(true);
		chat.setEnabled(false);
		add(vistaScroll = new JScrollPane(chat));
		add(entrada = new JTextField(20));
		add(btnEnviar = new JButton("Enviar"));
		
		//----------------------MYIP--------------------------
		try {
			myIp = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		//----------------------OYENTES--------------------------
		entrada.addActionListener(new AccionEnviarData());
		btnEnviar.addActionListener(new AccionEnviarData());
		
		//----------------------DATA--------------------------
		SenialConexion signal = new SenialConexion();
	}
	
	//-------------------AVISAR AL SERVIDOR DE USUARIO CONECTADO----------------------
	class SenialConexion implements Runnable {
		
		private String nickSignal, mensajeSignal, ipSignal;
		private Thread hilo;
		
		public SenialConexion() {
			nickSignal = nickUsuario;
			mensajeSignal = "onlinex";
			ipSignal = myIp;
			
			hilo = new Thread(this);
			hilo.start();
		}

		@Override
		public void run() {

			PaqueteData paqueteSignal = new PaqueteData(mensajeSignal, nickSignal, ipSignal);
			
			try {
				// se abre ecnhufe
				Socket enchufeSignal = new Socket(ipSignal, 9999);
				// se abre flujo
				ObjectOutputStream flujoSignal = new ObjectOutputStream(enchufeSignal.getOutputStream());
				// se monta data
				flujoSignal.writeObject(paqueteSignal);
				
				// se cierran enchufes y flujos
				enchufeSignal.close();
				flujoSignal.close();
				
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//----------------------ACCI�N ENVIAR MENSAJES--------------------------
	public class AccionEnviarData implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {

			if (e.getSource() == btnEnviar || e.getSource() == entrada) {
				
				String mensaje = entrada.getText();
				String nick = nickUsuario;
				String contacto = myIp;
				
				try {
					// ase abre enchufe
					Socket enchufe = new Socket(myIp, 9999);
					// se abre flujo
					ObjectOutputStream flujoOut = new ObjectOutputStream(enchufe.getOutputStream());
					// se instancia la data a enviar
					PaqueteData paqueteOut = new PaqueteData(mensaje, nick, contacto);
					// se monta la data al flujo
					flujoOut.writeObject(paqueteOut);
					
					// se cierran enchufes y flujos
					enchufe.close();
					flujoOut.close();
					
				} catch (UnknownHostException e1) {
					System.out.println(e1.getMessage());
					e1.printStackTrace();
				} catch (IOException e1) {
					System.out.println(e1.getMessage());
					e1.printStackTrace();
				}
				
				//----------------------------ACCI�N LOCAL------------------------------
				chat.append("\n" + nickUsuario.toUpperCase() + ": " + entrada.getText());
				entrada.setText("");
				entrada.requestFocus();
				
				System.out.println("msj enviado | my ip: " + myIp);
			}
		}
	}
	
	//----------------------RECIBIR MENSAJES--------------------------
	class RecibirData implements Runnable {
		
		private String nickIn, mensajeIn, ipIn;
		private Thread hilo;
		private PaqueteData paqueteIn;
		
		public RecibirData() {
			PaqueteData paqueteIn = new PaqueteData(mensajeIn, nickIn, ipIn);
			hilo = new Thread(this);
			hilo.start();
		}
		
		@Override
		public void run() {

			try {
				ServerSocket enchufeServer = new ServerSocket(9090);
				
				while (true) {
					
					// se abre enchufe
					Socket enchufeIn = enchufeServer.accept();
					// se abre flujo
					ObjectInputStream flujoIn = new ObjectInputStream(enchufeIn.getInputStream());
					
					paqueteIn = (PaqueteData) flujoIn.readObject();
					nickIn = paqueteIn.getNick();
					mensajeIn = paqueteIn.getMensaje();
					ipIn = paqueteIn.getIp();
					
					System.out.println("Nick recibido: " +  paqueteIn.getNick());
					System.out.println("Mensaje recibido: " +  paqueteIn.getMensaje());
					
					// se cierran enchufes y flujos
					enchufeIn.close();
					flujoIn.close();
					
					if (!mensajeIn.equals("onlinex")) {
						System.out.println("Entr� a mensaje recibido diferente de onlinex");
						//----------------------AGREGAR DATA AL CHAT-------------------------
						chat.append("\nRecibidox: " + nickIn + ": " + mensajeIn);
						
					} else {
						contactos.addItem(ipIn);
						System.out.println("Ip en bucle else: " + ipIn);
					}
				}
				
			} catch (IOException e) {
				System.out.println("Mensaje Error: " + e.getMessage());
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				System.out.println("Mensaje Error: " + e.getMessage());
				e.printStackTrace();
			}
		}
	}
}
//----------------------CLASE PAQUETE DATA--------------------------
class PaqueteData implements Serializable {
	private String mensaje, nick, ip;
	
	public PaqueteData(String mensaje, String nick, String ip) {
		this.mensaje = mensaje;
		this.nick = nick;
		this.ip = ip;
	}

	public String getMensaje() {
		return mensaje;
	}

	public String getNick() {
		return nick;
	}

	public String getIp() {
		return ip;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
}