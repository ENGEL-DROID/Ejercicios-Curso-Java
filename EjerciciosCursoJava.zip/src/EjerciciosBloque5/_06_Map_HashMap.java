package EjerciciosBloque5;

import java.util.HashMap;
import java.util.Map;

public class _06_Map_HashMap {

	public static void main(String[] args) {

		// ---------------------CREAR COLECCI�N-----------------------------
		System.out.println("\nImprimir la colecci�n:");
		HashMap<String, Empleado> empleados = new HashMap<String, Empleado>();
		
		empleados.put("101", new Empleado("Ricardo"));
		empleados.put("102", new Empleado("Mar�a"));
		empleados.put("103", new Empleado("Annabel"));
		empleados.put("104", new Empleado("Andr�s"));
		empleados.put("105", new Empleado("Diego"));
		empleados.put("106", new Empleado("Laura"));
		
		System.out.println(empleados);

		// ---------------------ELIMINAR UN EMPLEADO-----------------------------
		System.out.println("\nEmpleado 104 eliminado:");
		
		empleados.remove("104");
		
		System.out.println(empleados);
		
		// ---------------------SUSTITUIR UN EMPLEADO-----------------------------
		System.out.println("\nEmpleado 102 sustituido por Juana:");
		
		empleados.replace("102", new Empleado("Juana"));
		
		System.out.println(empleados);
		
		// ------------------IMPRIMIR COLECCI�N CON ENTRYSET--------------------------
		System.out.println("\nColecci�n impresa con entrySet():");
		
		System.out.println(empleados.entrySet());
		
		// ----------------IMPRIMIR COLECCI�N CON FOREACH Y ENTRY------------------------
		System.out.println("\nColecci�n impresa con foreach y Map.Entry:");
		
		for (Map.Entry<String, Empleado> empleado : empleados.entrySet()) {
			String clave = empleado.getKey();
			Empleado data = empleado.getValue();
			System.out.println("Clave= " +  clave + " | Data= " + data);
		}
	}
}

// -----------------CLASE EMPLEADO--------------------------
class Empleado {
	
	private String nombre;
	private double sueldo;
	
	public Empleado(String nombre) {

		this.nombre = nombre;
		sueldo = 2000;
	}
	
	public String toString() {
		return " Empleado: " + nombre + ", Sueldo: " + sueldo;
	}
}