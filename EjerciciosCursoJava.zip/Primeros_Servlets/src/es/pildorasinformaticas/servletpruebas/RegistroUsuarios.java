package es.pildorasinformaticas.servletpruebas;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegistroUsuarios")
public class RegistroUsuarios extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RegistroUsuarios() {
        super();
    }
    
    // Salida usando el m�todo Get
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter salida = response.getWriter();
		
		salida.println("<html><body>");
		
		salida.println("<h3>Datos Ingresados (M�todo Get)</h3>");
		
		salida.println("Nombre introducido: " + request.getParameter("nombre") + "<br>");

		salida.println("Apellido introducido: " + request.getParameter("apellido"));
	
		salida.println("<br><br>");
	
		salida.println("</body></html>");
	}

	// Salida usando el m�todo Post
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
		response.setContentType("text/html"); // En el Post se debe especificar el tipo de contenido
		
		PrintWriter salida = response.getWriter();
		
		salida.println("<html><body>");
		
		salida.println("<h3>Datos Ingresados (M�todo Post)</h3>");
		
		salida.println("Nombre introducido: " + request.getParameter("nombre") + "<br>");
		
		salida.println("Apellido introducido: " + request.getParameter("apellido"));

		salida.println("<br><br>");
		
		salida.println("</body></html>");
		
	}

}
