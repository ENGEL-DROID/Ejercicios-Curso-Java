package es.pildorasinformaticas.servletpruebas;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// NOTA: Todo �ste c�digo se ha generado autom�ticamente por Eclipse al crear un archivo nuevo de tipo Servlet

@WebServlet("/PrimerServlet")
public class PrimerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public PrimerServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 1er Paso: Se especifica el formato de respuesta creando un objeto del tipo PrintWriter
		PrintWriter salida = response.getWriter();
		
		// 2do Paso: Generar Respuesta de la Petici�n
		salida.println("<html><body>");
		salida.println("<h1 style='text-align: center'>Prueba Servlet</h1>");
		salida.println(" ");
		salida.println(" ");
		salida.println("Fecha y hora actual: " + new Date());
		salida.println(" ");
		salida.println(" ");
		salida.println("<p>Contenido de la P�gina Html</p>");
		salida.println("<p>Contenido de la P�gina Html</p>");
		salida.println("<p>Contenido de la P�gina Html</p>");
		salida.println("<p>Contenido de la P�gina Html</p>");
		salida.println("<p>Contenido de la P�gina Html</p>");
		salida.println(" ");
		salida.println(" ");
		salida.println("</body></html>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
