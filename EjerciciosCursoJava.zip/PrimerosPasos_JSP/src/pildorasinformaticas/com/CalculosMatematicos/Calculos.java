package pildorasinformaticas.com.CalculosMatematicos;

public class Calculos {
	
	// se crean todos en static para que no sea necesario instanciar la clase
	
	private static int resultado;

	public static int metodoSuma(int num1, int num2) {
		resultado = num1 + num2;
		return resultado;
	}
	
	public static int metodoResta(int num1, int num2) {
		resultado = num1 - num2;
		return resultado;
	}
	
	public static int metodoMultiplica(int num1, int num2) {
		resultado = num1 * num2;
		return resultado;
	}

}
