package pildorasinformaticas.com.jsptags;

public class Empleado {
	
	private String nombre, apellido, puesto;
	private double salario;
	
	// constructor y variables generados autom�ticamente Source > Generate Constructor using Fields
	public Empleado(String nombre, String apellido, String puesto, double salario) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.puesto = puesto;
		this.salario = salario;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public String getPuesto() {
		return puesto;
	}

	public double getSalario() {
		return salario;
	}

}
