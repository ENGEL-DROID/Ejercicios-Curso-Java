package com.ejercicios.servlets.pipex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PrimerServlet")
public class _12_PrimerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public _12_PrimerServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html><body style=\"font-family: roboto; color: #1f4060; padding: 10%;\">");
		out.println("<head><style>h1{text-align: center;}</style></head>");
		out.println("<h1>Primer Servlet</h1>");
		out.println("La fecha actual es: " + new java.util.Date() + "<br>");
		out.println("<h3>Esto es un contenido de la p�gina</h3>");
		out.println("<h3>Esto es un contenido de la p�gina</h3>");
		out.println("<h3>Esto es un contenido de la p�gina</h3>");
		out.println("<h3>Esto es un contenido de la p�gina</h3>");
		out.println("<h3>Esto es un contenido de la p�gina</h3>");
		out.println("<h3>Esto es un contenido de la p�gina</h3>");
		out.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
